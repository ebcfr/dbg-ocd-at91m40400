#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : bo_load.c
//* Object              : Load program in RAM
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  :
//*     init_usart
//*     disable_usart
//*     receive_frame
//*     define_as_pio
//*     define_as_input
//*     read_pio_pin
//* Exported resources  : BootLoad
//*
//* 1.0 25/04/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up.
//*-----------------------------------------------------------------------------

/*----- Files to be included Definition -----*/

#define AT91M40400
#include "..\..\Include\std_c.h"
#include "..\..\Include\pio.h"
#include "..\..\Include\usart.h"
#include "at91eb01.h"       /* AT91EB01 description */

/*----- Types and Constants Definition -----*/

/* Hardware description */
#define NB_USART            2
#define PIO_IRQ0    (9)
#define SSRAM_ADDR  (0x02000000)
#define BUFFER_SIZE (0x0FFFF)

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;
#include "bo_usart.c"
#undef _REFERENCE

/*---- Internal Resources Definition -----*/
/* None */

/*---- External Resources Definition -----*/
#define _REFERENCE(x)   x
#define CORPS
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : BootLoad
//* Object              : Main function of the bootloader
//* Input Parameters    : none
//* Output Parameters   : none
//* Functions called    :
//*     init_usart, disable_usart, receive_frame
//*-----------------------------------------------------------------------------
_REFERENCE (int BootLoad ( void ))
#ifdef CORPS
//* Begin
{
    u_int       usart_id ;

    //* For each USART
    for (usart_id = 0  ;  usart_id < NB_USART  ;  usart_id ++)
    {
        //* Initialize USART
        init_usart (usart_id, StandardAsyncMode, (usart_id == 0 ? 18 : 53), 0);
        //* Initialize PDC Reception
        receive_frame (usart_id, ((char *)SSRAM_ADDR), BUFFER_SIZE, 1000 );
    //* EndFor
    }

    //* Wait for IRQ0 pin asserted
    while (!(PIO_BASE->PIO_PDSR & SW5));

    //* For each USART
    for (usart_id = 0  ;  usart_id < NB_USART  ;  usart_id ++)
    {
        //* Disable USART
        disable_usart (usart_id);
    //* EndFor
    }

    return(SSRAM_ADDR);
//* End
}
#endif
