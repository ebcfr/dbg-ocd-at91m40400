//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : at91eb01.h
//* Object              : AT91EB01 Features Definition File
//*
//* 1.0 04/08/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up.
//*-----------------------------------------------------------------------------

#ifndef at91eb01_h
#define at91eb01_h

//*----- Types and Constants Definition -----*/

/* peripheral control */
#define PERIPHERAL      (TXD0 | RXD0 | TXD1 | RXD1 | PIN_FIQ | PIN_IRQ0)

/* PIO output control */
#define PIO_OUT         (TIOA0 | TIOB0 | TIOA1)

#define LED1            TIOA0                   /* LED 1 - Red */
#define LED2            TIOA1                   /* LED 2 - Amber */
#define LED3            TIOB0                   /* LED 3 - Green */
#define LED1_2          (LED1 | LED2)           /* LEDs 1 and 2 */
#define LED1_3          (LED1 | LED3)           /* LEDs 1 and 3 */
#define LED2_3          (LED2 | LED3)           /* LEDs 2 and 3 */
#define LED1_2_3        (LED1 | LED2 | LED3)    /* LEDs 1, 2 and 3 */
#define SW3             PIN_FIQ                 /* SW3 button */
#define SW4             TIOB1                   /* SW4 button */
#define SW5             PIN_IRQ0                /* SW5 button */

#endif /* at91eb01_h */
