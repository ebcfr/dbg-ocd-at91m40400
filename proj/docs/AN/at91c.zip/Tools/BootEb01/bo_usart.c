#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : bo_usart.c
//* Object              : USART management for Boot AT91DB01
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : None
//* Exported resources  :
//*     init_usart, disable_usart, receive_frame
//*
//* 1.0 05/05/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up.
//*-----------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#define AT91M40400
#include "..\..\include\std_c.h"
#include "..\..\include\usart.h"
#include "at91eb01.h"       /* AT91EB01 description */

/*----- Types and Constants Definition -----*/
/* None */

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;
#undef _REFERENCE

/*---- Internal Resources Definition -----*/
/* None */

/*---- External Resources Definition -----*/

#define _REFERENCE(x)   x
#define CORPS
#endif

//*P
//*---------------------------------------------------------------------------
//* Function Name       : init_usart
//* Object              : Initialize an USART.
//* Input Parameters    : <usart_id> = the USART to initialize
//*                     : <mode> = the Mode Register to be programmed
//*                     : <speed> = the BRDR to be programmed
//*                     : <timeguard> = the TTGR to be programmed
//* Output Parameters   : TRUE if USART number is correct, else, FALSE
//* Functions called    : None
//*---------------------------------------------------------------------------
_REFERENCE (u_int init_usart ( u_int usart_id ,
                               u_int mode ,
                               u_int speed ,
                               u_int timeguard ))
#ifdef CORPS
//* Begin
{
    StructUSART *ad_usart;

    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;
    ad_usart = (usart_id == 0 ? USART0_BASE : USART1_BASE);

    //* Reset receiver and transmitter
    ad_usart->US_CR = RSTRX | RSTTX | RXDIS | TXDIS ;

    //* Clear Transmit and Receive Counters
    ad_usart->US_RCR = 0 ;
    ad_usart->US_TCR = 0 ;

    //* Define the baud rate divisor register
    ad_usart->US_BRGR = speed ;

    //* Define the USART mode
    ad_usart->US_MR = mode  ;

    //* Write the Timeguard Register
    ad_usart->US_TTGR = timeguard ;

    //* Enable receiver and transmitter
    ad_usart->US_CR = RXEN | TXEN ;

    //* Return true
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : disable_usart
//* Object              : Disable an USART.
//* Input Parameters    : <usart_id> = the USART to disable
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : None
//*-----------------------------------------------------------------------------
_REFERENCE (u_int disable_usart ( u_int usart_id ))
#ifdef CORPS
//* Begin
{
    StructUSART *ad_usart;

    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;
    ad_usart = (usart_id == 0 ? USART0_BASE : USART1_BASE);

    //* Disable all interrupts
    ad_usart->US_IDR = 0xFFFFFFFF ;

    //* Abort the Peripheral Data Transfers
    ad_usart->US_RCR = 0 ;
    ad_usart->US_TCR = 0 ;

    //* Disable receiver and transmitter and stop any activity immediately
    ad_usart->US_CR = TXDIS | RXDIS | RSTTX | RSTRX ;

    //* Return true
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : receive_frame
//* Object              : Receive a complete frame.
//* Input Parameters    : <usart_id> = the USART where receive the byte
//*                     : <pt_buffer> = the address of the receive buffer
//*                     : <max_size> = the maximum number of bytes to be
//*                     : received
//*                     : <timeout> = the inter-character time delay in
//*                     : number of byte
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE ( u_int receive_frame ( u_int usart_id ,
                                   char *pt_buffer ,
                                   u_int max_size ,
                                   u_int timeout ))
#ifdef CORPS
//* Begin
{
    StructUSART *ad_usart;

    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;
    ad_usart = (usart_id == 0 ? USART0_BASE : USART1_BASE);

    //* Store the timeout value
    ad_usart->US_RTOR = (timeout * 10 / 4) ;
    //* Restart the timeout logic
    ad_usart->US_CR = STTTO ;
    //* Store the address of the buffer
    ad_usart->US_RPR = (u_int) pt_buffer ;
    //* Store the number of bytes to transmit
    ad_usart->US_RCR = max_size ;
    //* Return true
    return ( TRUE ) ;
}
//* End
#endif
