#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : bo_entry.c
//* Object              : Main loop of AT91EB01 test
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : BootFts, BootLoad
//* Exported resources  : BootEntry
//*
//* 1.0 04/09/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up.
//*-----------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#define AT91M40400
#include "..\..\Include\std_c.h"
#include "..\..\Include\usart.h"
#include "..\..\Include\pio.h"
#include "at91eb01.h"       /* AT91EB01 description */

/*----- Types and Constants Definition -----*/
#define ADDR_ANGEL      0x01002000

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;
#include "bo_load.c"
#include "bo_fts.c"
#undef _REFERENCE

/*---- Internal Resources Definition -----*/
/* None */

/*---- External Resources Definition -----*/

#define _REFERENCE(x)   x
#define CORPS
#endif

//*----------------------------------------------------------------------------
//* Function Name           : BootEntry
//* Object                  : Entry point of boot
//* Input Parameters        : None
//* Output Parameters       : None
//* Functions called        :
//*----------------------------------------------------------------------------
_REFERENCE (int BootEntry (void ))
#ifdef CORPS
//* Begin
{
    //* -- Set up PIO
    PIO_BASE->PIO_PDR  = PERIPHERAL;
    PIO_BASE->PIO_OER  = PIO_OUT;
    PIO_BASE->PIO_CODR = PIO_OUT;           /* Turn LEDs off */
    PIO_BASE->PIO_IDR  = 0xFFFFFFFF;        /* Disable PIO interrupts */

    //* Repeat for ever
    for (;;)
    {
        //* If SW4 button pressed, Load in SRAM
        if (PIO_BASE->PIO_PDSR & SW4)
        {
            //* Expect SW3 un-pressed
            PIO_BASE->PIO_SODR = LED1;
            return BootLoad();
        }//* EndIf

        //* If SW3 button pressed, Functional Test Software
        if (PIO_BASE->PIO_PDSR & SW3)
        {
            //* Expect SW4 un-pressed
            PIO_BASE->PIO_SODR = LED1_2_3;
            while (PIO_BASE->PIO_PDSR & SW3);
            PIO_BASE->PIO_CODR = LED1_2_3;
            BootFts();
        }//* EndIf

        //* If no button pressed, Angel
        PIO_BASE->PIO_SODR = LED2;
        return (ADDR_ANGEL);

    }//* EndRepeat

//* End
}
#endif
