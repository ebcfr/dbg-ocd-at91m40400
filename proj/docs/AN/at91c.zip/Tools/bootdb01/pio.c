#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : lib_pio.c
//* Object              : PIO management for Boot AT91DB01
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : None
//* Exported resources  :
//*     define_as_pio, define_as_peripheral, define_as_input, read_pio_pin
//*
//* 1.0 05/05/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up.
//*-----------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#include "pio.h"

/*----- Types and Constants Definition -----*/

#define NB_PIO_CTRL     1
#define PIO_BASE            ((StructPIO *) 0xFFFF0000 )

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)       extern x;
#undef _REFERENCE

/* Import the PIO Interrupt Handlers written in assembler */

/*---- Internal Resources Definition -----*/
/* None */

/*---- External Resources Definition -----*/

#define _REFERENCE(x)       x
#define CORPS
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : define_as_pio
//* Object              : Define pins as managed by the PIO controller
//* Input Parameters    : <mask> defines the pins to managed by the PIO
//* Output Parameters   : the value of the PIO Status Register
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int define_as_pio ( u_int mask ))
#ifdef CORPS
//* Begin
{
    //* Write the argument mask in the PIO Enable Register
    PIO_BASE->PIO_PER = mask ;
    //* Return the value of the PIO Status Register
    return ( PIO_BASE->PIO_PSR ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : define_as_peripheral
//* Object              : Define pins as managed by a peripheral
//* Input Parameters    : <mask> defines the pins to managed by
//*                     : the peripheral
//* Output Parameters   : the value of the PIO Status Register
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int define_as_peripheral ( u_int mask ))
#ifdef CORPS
//* Begin
{
    //* Write the argument mask in the PIO Disable Register
    PIO_BASE->PIO_PDR = mask ;
    //* Return the value of the PIO Status Register
    return ( PIO_BASE->PIO_PSR ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : define_as_input
//* Object              : Define pins as input if managed by the parallel IO
//* Input Parameters    : <mask> defines the pins to be defined as input
//* Output Parameters   : a mask showing the pins really defined as input
//*                     : bit is set if corresponding pin is an input
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int define_as_input ( u_int mask ))
#ifdef CORPS
//* Begin
{
    //* Write the argument mask in the Output Disable Register
    PIO_BASE->PIO_ODR = mask ;
    //* Return PIO Status Register AND NOT PIO Direction Status Register
    return ( PIO_BASE->PIO_PSR & (~(PIO_BASE->PIO_OSR)) ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : read_pio_pin
//* Object              : Read the state of the PIO pins
//* Input Parameters    : None
//* Output Parameters   : the state of the 32 pins ( on the pads )
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int read_pio_pin ( void ))
#ifdef CORPS
//* Begin
{
    //* Return the Pin Data Status Register
    return ( PIO_BASE->PIO_PDSR ) ;
}
//* End
#endif
