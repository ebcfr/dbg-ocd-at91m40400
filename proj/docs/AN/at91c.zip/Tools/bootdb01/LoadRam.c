#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : LoadRam.c
//* Object              : Load program in RAM
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  :
//*     init_usart
//*     disable_usart
//*     receive_frame
//*     define_as_pio
//*     define_as_input
//*     read_pio_pin
//* Exported resources  : main
//*
//* 1.0 25/04/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up.
//*-----------------------------------------------------------------------------

/*----- Files to be included Definition -----*/

#include    "usart.h"
#include    "pio.h"

/*----- Types and Constants Definition -----*/

/* Hardware description */
#define NB_USART            2
#define PIO_IRQ0    (9)
#define SSRAM_ADDR  (0x00100000)
#define BUFFER_SIZE (0x0FFFF)

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;
#include    "usart.c"
#include    "pio.c"
#undef _REFERENCE

/*---- Internal Resources Definition -----*/
/* None */

/*---- External Resources Definition -----*/
#define _REFERENCE(x)   x
#define CORPS
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : main
//* Object              : Main function of EchoIrq.c
//* Input Parameters    : none
//* Output Parameters   : none
//* Functions called    :
//*     init_usart, disable_usart, receive_frame
//*-----------------------------------------------------------------------------
_REFERENCE (int main ( void ))
#ifdef CORPS
//* Begin
{
    u_int       usart_id ;

    //* For each USART
    for (usart_id = 0  ;  usart_id < NB_USART  ;  usart_id ++)
    {
        //* Initialize USART
        init_usart (usart_id, StandardAsyncMode, (usart_id == 0 ? 17 : 52), 0);
        //* Initialize PDC Reception
        receive_frame (usart_id, ((char *)SSRAM_ADDR), BUFFER_SIZE, 1000 );
    //* EndFor
    }

    //* Define PBINT as an input PIO
    define_as_pio (1 << PIO_IRQ0);
    define_as_input (1 << PIO_IRQ0);

    //* While (IRQ0 pin not asserted)
    while ((read_pio_pin() & (1 << PIO_IRQ0)) == 0)
    {
    //* EndWhile
    }

    //* For each USART
    for (usart_id = 0  ;  usart_id < NB_USART  ;  usart_id ++)
    {
        //* Disable USART
        disable_usart (usart_id);
    //* EndFor
    }

    return(SSRAM_ADDR);
//* End
}
#endif
