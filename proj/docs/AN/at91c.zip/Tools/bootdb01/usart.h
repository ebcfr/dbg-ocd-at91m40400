//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : usart.h
//* Object              : USART Definition File
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* 1.0 27/10/97 JCZ    : Creation
//* 1.1 21/04/98 JLV    : Add brackets
//* 2.0 21/10/98 JCZ    : Clean up.
//*-----------------------------------------------------------------------------

#ifndef usart_h
#define usart_h

#include "std_c.h"

/*----------------------------*/
/* USART Structure Definition */
/*----------------------------*/

typedef struct
{
    at91_reg        US_CR ;     /* Control Register */
    at91_reg        US_MR ;     /* Mode Register */
    at91_reg        US_IER ;    /* Interrupt Enable Register */
    at91_reg        US_IDR ;    /* Interrupt Disable Register */
    at91_reg        US_IMR ;    /* Interrupt Mask Register */
    at91_reg        US_CSR ;    /* Channel Status Register */
    at91_reg        US_RHR ;    /* Receive Holding Register */
    at91_reg        US_THR ;    /* Transmit Holding Register */
    at91_reg        US_BRGR ;   /* Baud Rate Generator Register */
    at91_reg        US_RTOR ;   /* Receiver Timeout Register */
    at91_reg        US_TTGR ;   /* Transmitter Timeguard Register */
    at91_reg        Reserved ;
    at91_reg        US_RPR ;    /* Receiver Pointer Register */
    at91_reg        US_RCR ;    /* Receiver Counter Register */
    at91_reg        US_TPR ;    /* Transmitter Pointer Register */
    at91_reg        US_TCR ;    /* Transmitter Counter Register */
} StructUSART ;

/*------------------*/
/* Control Register */
/*------------------*/
/* Reset Receiver */
#define RSTRX                       (1<<2)
/* Reset Transmitter */
#define RSTTX                       (1<<3)
/* Receiver Enable */
#define RXEN                        (1<<4)
/* Receiver Disable */
#define RXDIS                       (1<<5)
/* Transmitter Enable */
#define TXEN                        (1<<6)
/* Transmitter Disable */
#define TXDIS                       (1<<7)
/* Reset Status Bits */
#define RSTSTA                      (1<<8)
/* Start Break */
#define STTBRK                      (1<<9)
/* Stop Break */
#define STPBRK                      (1<<10)
/* Start Timeout */
#define STTTO                       (1<<11)
/* Send Address */
#define SENDA                       (1<<12)
/* Force Load */
#define FORCEL                      (1<<15)

/*---------------*/
/* Mode Register */
/*---------------*/

/* Clock Selection */
#define CLKS                (3<<4)
#define USClk_MCK           (0<<4)
#define USClk_MCK8          (1<<4)
#define USClk_SCK           (2<<4)

/* Byte Length */
#define CHRL                (3<<6)
#define FiveBits            (0<<6)
#define SixBits             (1<<6)
#define SevenBits           (2<<6)
#define EightBits           (3<<6)

/* Synchronous Mode Enable */
#define SYNC                (1<<8)

/* Parity Mode */
#define PAR                 (7<<9)
#define EvenParity          (0<<9)
#define OddParity           (1<<9)
#define SpaceParity         (2<<9)
#define MarkParity          (3<<9)
#define NoParity            (4<<9)
#define MultiDropMode       (6<<9)

/* Stop Bit Number */
#define NBSTOP              (3<<12)
#define Stop1Bit            (0<<12)
#define Stop1_5Bit          (1<<12)
#define Stop2Bit            (2<<12)

/* Channel Mode */
#define CHMODE              (3<<14)
#define NormalMode          (0<<14)
#define AutomaticEcho       (1<<14)
#define LocalLoopback       (2<<14)
#define RemoteLoopback      (3<<14)

/* 9 Bit Mode */
#define MODE9               (1<<17)

/* Baud Rate Output Enable */
#define CLKO                (1<<18)

/* Standard Asynchronous Mode : 8 bits , 1 stop , no parity */
#define StandardAsyncMode   (NormalMode + Stop1Bit + NoParity + EightBits + USClk_MCK)

/* Standard External Asynchronous Mode : 8 bits , 1 stop , no parity */
#define ExternalStandardAsyncMode   (NormalMode + Stop1Bit + NoParity + EightBits + USClk_SCK)

/* Standard Synchronous Mode : 8 bits , 1 stop , no parity */
#define StandardSyncMode    (SYNC + NormalMode + Stop1Bit + NoParity + EightBits + USClk_MCK)

/* SCK used Label */
#define SCK_USED                (CLKO | USClk_SCK)

/*-------------------------*/
/* Channel Status Register */
/*-------------------------*/

/* Receiver Ready */
#define RXRDY                   (1<<0)

/* Transmitter Ready */
#define TXRDY                   (1<<1)

/* Receiver Break */
#define RXBRK                   (1<<2)

/* End of Receiver PDC Transfer */
#define ENDRX                   (1<<3)

/* End of Transmitter PDC Transfer */
#define ENDTX                   (1<<4)

/* Overrun Error */
#define OVRE                    (1<<5)

/* Framing Error */
#define FRAME                   (1<<6)

/* Parity Error */
#define PARE                    (1<<7)

/* Receiver Timeout */
#define TIMEOUT                 (1<<8)

/* Transmitter Empty */
#define TXEMPTY                 (1<<9)

#define MASK_IRQ_TX         (TXRDY | ENDTX | TXEMPTY)
#define MASK_IRQ_RX         (RXRDY | ENDRX | TIMEOUT)
#define MASK_IRQ_ERROR      (PARE | FRAME | OVRE | RXBRK)

/*-------------------------------*/
/* USART Handler type definition */
/*-------------------------------*/

typedef void (*TypeUSARTHandler) ( StructUSART *usart_pt ) ;

/*-------------------------------*/
/* USART Handler Table Structure */
/*-------------------------------*/

typedef struct
{
    u_int               ErrorMask ;
    TypeUSARTHandler    ErrorHandler ;
    u_int               RxMask ;
    TypeUSARTHandler    RxHandler ;
    u_int               TxMask ;
    TypeUSARTHandler    TxHandler ;
} StructUSARTHandlerTable ;

#endif /* usart_h */
