#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : lib_us.c
//* Object              : USART management for Boot AT91DB01
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  :
//*     define_as_peripheral, define_as_pio
//* Exported resources  :
//*     init_usart, disable_usart, receive_frame
//*
//* 1.0 05/05/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up.
//*---------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#include "usart.h"

/*----- Types and Constants Definition -----*/

#define NB_USART            2
#define USART0_BASE     ((StructUSART *) 0xFFFD0000)
#define USART1_BASE     ((StructUSART *) 0xFFFCC000)

#define PIO_USART0      PIO_CTRL
#define SCK0            (1<<13)
#define TXD0            (1<<14)
#define RXD0            (1<<15)
#define PIN_USART0      (SCK0|TXD0|RXD0)

#define PIO_USART1      PIO_CTRL
#define SCK1            (1<<20)
#define TXD1            (1<<21)
#define RXD1            (1<<22)
#define PIN_USART1      (SCK1|TXD1|RXD1)

/*----- Imported Resources Definition -----*/
#define _REFERENCE(x)   extern x;

#include "pio.c"

#undef _REFERENCE

/*---- Internal Resources Definition -----*/

/* USARTs Constant Table Structure */
typedef struct
{
    StructUSART     *UsartBase ;
    u_int               PioPinRxTx ;
    u_int               PioPinSck ;
} StructConstUsart ;

/* USARTs Constant Table Structure */
const   StructConstUsart    ConstUsart[NB_USART] =
{
    /* Usart 0 */
    {
        USART0_BASE ,
        RXD0|TXD0,
        SCK0,
    } ,
    /* Usart 1 */
    {
        USART1_BASE ,
        RXD1|TXD1,
        SCK1,
    }
} ;

/*---- External Resources Definition -----*/

#define _REFERENCE(x)   x
#define CORPS
#endif

//*P
//*---------------------------------------------------------------------------
//* Function Name       : init_usart
//* Object              : Initialize an USART.
//* Input Parameters    : <usart_id> = the USART to initialize
//*                     : <mode> = the Mode Register to be programmed
//*                     : <speed> = the BRDR to be programmed
//*                     : <timeguard> = the TTGR to be programmed
//* Output Parameters   : TRUE if USART number is correct, else, FALSE
//* Functions called    : define_as_peripheral
//*---------------------------------------------------------------------------
_REFERENCE (u_int init_usart ( u_int usart_id ,
                               u_int mode ,
                               u_int speed ,
                               u_int timeguard ))
#ifdef CORPS
//* Begin
{
    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* Reset receiver and transmitter
    ConstUsart[usart_id].UsartBase->US_CR = RSTRX | RSTTX | RXDIS | TXDIS ;

    //* Define RXD and TXD as peripheral
    define_as_peripheral ( ConstUsart[usart_id].PioPinRxTx ) ;

    //* Clear Transmit and Receive Counters
    ConstUsart[usart_id].UsartBase->US_RCR = 0 ;
    ConstUsart[usart_id].UsartBase->US_TCR = 0 ;

    //* Define the baud rate divisor register
    ConstUsart[usart_id].UsartBase->US_BRGR = speed ;

    //* Define the USART mode
    ConstUsart[usart_id].UsartBase->US_MR = mode  ;

    //* Write the Timeguard Register
    ConstUsart[usart_id].UsartBase->US_TTGR = timeguard ;

    //* Enable receiver and transmitter
    ConstUsart[usart_id].UsartBase->US_CR = RXEN | TXEN ;

    //* Return true
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : disable_usart
//* Object              : Disable an USART.
//* Input Parameters    : <usart_id> = the USART to disable
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : define_as_pio
//*-----------------------------------------------------------------------------
_REFERENCE (u_int disable_usart ( u_int usart_id ))
#ifdef CORPS
//* Begin
{
    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* Define all USARTs pins as pio
    define_as_pio ( ConstUsart[usart_id].PioPinRxTx |
                    ConstUsart[usart_id].PioPinSck ) ;

    //* Disable all interrupts
    ConstUsart[usart_id].UsartBase->US_IDR = 0xFFFFFFFF ;

    //* Abort the Peripheral Data Transfers
    ConstUsart[usart_id].UsartBase->US_RCR = 0 ;
    ConstUsart[usart_id].UsartBase->US_TCR = 0 ;

    //* Disable receiver and transmitter and stop any activity immediately
    ConstUsart[usart_id].UsartBase->US_CR = TXDIS | RXDIS | RSTTX | RSTRX ;

    //* Return true
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : receive_frame
//* Object              : Receive a complete frame.
//* Input Parameters    : <usart_id> = the USART where receive the byte
//*                     : <pt_buffer> = the address of the receive buffer
//*                     : <max_size> = the maximum number of bytes to be
//*                     : received
//*                     : <timeout> = the inter-character time delay in
//*                     : number of byte
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE ( u_int receive_frame ( u_int usart_id ,
                                   char *pt_buffer ,
                                   u_int max_size ,
                                   u_int timeout ))
#ifdef CORPS
//* Begin
{
    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* Store the timeout value
    ConstUsart[usart_id].UsartBase->US_RTOR = (timeout * 10 / 4) ;
    //* Restart the timeout logic
    ConstUsart[usart_id].UsartBase->US_CR = STTTO ;
    //* Store the address of the buffer
    ConstUsart[usart_id].UsartBase->US_RPR = (u_int) pt_buffer ;
    //* Store the number of bytes to transmit
    ConstUsart[usart_id].UsartBase->US_RCR = max_size ;
    //* Return true
    return ( TRUE ) ;
}
//* End
#endif
