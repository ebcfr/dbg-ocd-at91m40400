//*-----------------------------------------------------------------------------//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name               : Flash_91.c
//* Object                  : FLASH programmer for :
//*                           . AT91EB01 - AT29LV1024
//*                           . AT91DB01 - AT29C020
//* Translator              : ARM Software Development Toolkit V2.11a
//*
//* 1.0 21/10/98 JLV        : Creation
//*-----------------------------------------------------------------------------
/* Include Standard c Libraries to allow stand alone compiling and operation */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* Define the specific for the flash memory system */
#define MAN_ATMEL           0x1F

#ifdef AT91EB01
#define TARGET_ID           "AT91EB01"
#define FLASH_TYPE          "AT29LV1024"
#define FLASH_ID            0X26
#define SECTOR_SIZE         256
#define MASK_ALGORITHM      0X0000FFFF
#endif

#ifdef AT91DB01
#define TARGET_ID           "AT91DB01"
#define FLASH_TYPE          "AT29C020"
#define FLASH_ID            0XDA
#define SECTOR_SIZE         (256 * 2)
#define MASK_ALGORITHM      0X0000FFFF
#endif

/* Specify the host files for the flash transfer */
static FILE *image;

/* Local routine defines for the flashwrt.c module */
#define MIN_NO_OF_ARGS   3

#define FILL_PATTERN     0x5a

#define FLASH_SEQ_ADD_1  (0x5555 << 1)
#define FLASH_SEQ_ADD_2  (0x2AAA << 1)

#define FLASH_WORD_COM_1 ((short)0xAAAA)
#define FLASH_WORD_COM_2 ((short)0x5555)
#define PROT_WORD_COM    ((short)0xA0A0)
#define ID_IN_WORD_COM   ((short)0x9090)
#define ID_OUT_WORD_COM   ((short)0xF0F0)

static int sector_size = 0;

static unsigned int sector[SECTOR_SIZE];

/* Pause for at least 20 ms */
static void Pause(void)
{
    time_t t=time(NULL);
    for (;time(NULL)-t < 1;) {
        /* Do nothing - just wait */
    }
}

static void DisplayHelp(void) {
  printf("\n");
  printf("Usage:\n");
  printf("load flash <filename> <address>\n");
  printf("where:\n");
  printf("  <filename> - binary file to program into flash\n");
  printf("  <address>  - beginning address to download\n");
  printf("\n");
}

int Identify(int base_addr)
{
    int manuf_code, device_code;

    printf("Trying to identify Flash at base address (0x%x)\n", base_addr);

    /* Enter Software Product Identification Mode  */
    *((volatile short *)(base_addr + FLASH_SEQ_ADD_1)) = FLASH_WORD_COM_1;
    *((volatile short *)(base_addr + FLASH_SEQ_ADD_2)) = FLASH_WORD_COM_2;
    *((volatile short *)(base_addr + FLASH_SEQ_ADD_1)) = ID_IN_WORD_COM;
    /* Wait 10 ms for the device to change state */
    Pause();

    /* Read Manufacturer and device code from the device */
    manuf_code  = (*((volatile short *) (base_addr + 0))) & 0x00FF;
    device_code = (*((volatile short *) (base_addr + 2))) & 0x00FF;

    /* Exit Software Product Identification Mode  */
    *((volatile short *)(base_addr + FLASH_SEQ_ADD_1)) = FLASH_WORD_COM_1;
    *((volatile short *)(base_addr + FLASH_SEQ_ADD_2)) = FLASH_WORD_COM_2;
    *((volatile short *)(base_addr + FLASH_SEQ_ADD_1)) = ID_OUT_WORD_COM;
    /* Wait 20 ms */
    Pause();

    /* Check the Manufacturer - Fail if not known */
    if (manuf_code != MAN_ATMEL) {
        printf ( "Error - Unexpected manufacturer %02x (expected ATMEL=%2x)\n",
                        manuf_code, MAN_ATMEL );
        return 1;
    }
    if (device_code != FLASH_ID) {
        printf ( "Error - Unexpected device %02x\n", device_code);
        return 1;
    }
    printf ("Flash recognised : %s\n", FLASH_TYPE);
    sector_size = SECTOR_SIZE;

  return 0;
}

/* write_sector
 *
 * This function writes the sector data from the image file to the specified
 * device in the specified sector size. The module checks that all of the data
 * is written before returning for the next sector write. Data protection is
 * set and operated with this module, data writes always need to be initiated
 * using protection after this operation
 *
 * We return the number of verify errors
 */
int write_sector(int base_addr, int load_addr, int size_sector,
                                    unsigned int data_addr[])
{
    int i;
    int verify_errors = 0;
    int expected;
    /* Indicate that we are doing something */
    printf(".");

    /* Enter Data protection routine code */
    *((volatile short *)(base_addr + FLASH_SEQ_ADD_1)) = FLASH_WORD_COM_1;
    *((volatile short *)(base_addr + FLASH_SEQ_ADD_2)) = FLASH_WORD_COM_2;
    *((volatile short *)(base_addr + FLASH_SEQ_ADD_1)) = PROT_WORD_COM;

    /* Write the data in full int steps - regardless of FLASH Data bus width */
    for (i = 0; i < (size_sector/2) ; i++) {
        ((short *) load_addr)[i] = ((short *)data_addr)[i];
    }

    /* Check that the final word has been written before continuing */
    expected = ((unsigned short *)data_addr)[(size_sector/2)-1];
    for (i=0;
         expected != ((volatile unsigned short *)load_addr)[(size_sector/2)-1];
         i++);
    if (i == 100000) {
        printf("\nUnable to program sector - check board for errors\n");
        exit(1);
    }
    /* Reread the sector and check it matches what we wrote */
    for (i = 0; i < (size_sector/4) ; i++) {
        if (((int *) load_addr)[i] != data_addr[i]) {
            printf("\nError - Verify failed at address %x (%x,%x)\n",
                        ((int *) load_addr)[i],
                        ((volatile int *) load_addr)[i], data_addr[i]);
                        verify_errors++;
        }
    }

    /* Return the number of cycles required to write the data */
    return verify_errors;
}

static void DownloadFileToFlash(char *filename, int addr_base, int addr_load)
{
    int sectors_done;
    int endflag;
    int errors=0;

    /* open the external FLASH Image file - any failure then exit */
    if ((image=fopen(filename,"rb"))==NULL) {
        printf("Error - Cannot open file image \"%s\"\n", filename);
        exit(1);
    }

    /* Show the image file being downloaded */
    printf("Input file is  :   %s \n", filename);
    printf("Load address is:   %x \n", addr_load);
    printf("Programming flash (\".\" = 1 sector)\n");

    /* Write the Image file to the FLASH Device in the required sector sizes */
    sectors_done=0;
    for (endflag = 0 ; !endflag ;) {
        int value_read;

        /* read file and write in sector sizes until not enough
           data to fill sector */
        if ((value_read = fread(sector, 1, sector_size, image)) != sector_size)
        {
            /* fill remaining sector data with fill pattern 0x5a */
            for (; value_read < sector_size ; value_read++) {
                ((char *)sector)[value_read] = FILL_PATTERN;
                endflag++;
            }
        }

        /* Write the image file to the specified device
           at the address required */
        errors += write_sector(addr_base, addr_load, sector_size, sector);
        if (++sectors_done == 16) {
            printf("\n");
            sectors_done=0;
        }

        /* increment the address for the address write by the sector size */
        addr_load += sector_size;
    }

    /* Close the external file and exit the program */
    fclose(image);
    if (errors==0) {
        printf("\nFlash written and verified successfully\n");
    } else {
        printf("\nFlash write failed with %i verify errors\n",errors);
    }
}

/* main
 *
 * This is the c library entry point and controlling function for
 * the whole  program. It checks that there is a specified file for
 * download and then  checks the identity of the flash device on
 * board.. The external file is then  opened and transferred to the
 * flash memory in the required sectors
 */
int main(int argc, char *argv[])
{
    int base_addr;
    int load_addr;

    printf("\n**** %s Flash Programming Utility ****\n", TARGET_ID);
    /* If no external file is present - warn the user then exit */
    if (argc < MIN_NO_OF_ARGS) {
        DisplayHelp();
        exit(1);
    }

    if (argv[1][0]=='-') {
        DisplayHelp();
        exit(1);
    }
    /* Get load address */
    sscanf(argv[2],"0x%x",&load_addr);
    /* Check the FLASH Device - if it isn't recognised then exit */
    base_addr = load_addr & ~MASK_ALGORITHM;
    if (Identify(base_addr)) {
        printf("Error - The Flash device is not recognised\n");
        exit(1);
    }
    DownloadFileToFlash(argv[1], base_addr, load_addr);

    return 0;
}
