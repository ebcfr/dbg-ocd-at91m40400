//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : prior_irq.h
//* Object              : Interrupt Sources Priority Definition File
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* 1.0 13/11/97 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

#ifndef prior_irq_h
#define prior_irq_h

/*----------------------------*/
/* Interrupt Sources Priority */
/*----------------------------*/

#ifdef AT91M40400
#define SW_IRQ_PRIORITY             4
#define USART0_IRQ_PRIORITY         4
#define USART1_IRQ_PRIORITY         4
#define TC0_IRQ_PRIORITY            3
#define TC1_IRQ_PRIORITY            3
#define TC2_IRQ_PRIORITY            3
#define PIO_IRQ_PRIORITY            5
#define WD_IRQ_PRIORITY             6
#define IRQ0_PRIORITY               3
#define IRQ1_PRIORITY               3
#define IRQ2_PRIORITY               3

#endif /* AT91M40400 */

#endif /* prior_irq_h */
