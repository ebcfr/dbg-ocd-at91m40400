//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : std_c.h
//* Object              : Standard C Definition File
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* 1.0 08/08/97 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

#ifndef std_c_h
#define std_c_h

//*---------------
//* Standard types
//*---------------
typedef unsigned int        u_int   ;
typedef unsigned short      u_short ;
typedef unsigned char       u_char ;

//*--------------
//* AT91 Register
//*--------------
#define at91_reg            volatile u_int

//*---------------
//* Boolean values
//*---------------
#define TRUE                1
#define FALSE               0

#endif /* std_c_h */
