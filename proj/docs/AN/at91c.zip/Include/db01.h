//*--------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*--------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : db01.h
//* Object              : AT91 Development Board Features Definition File
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* 1.0 14/09/98 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*--------------------------------------------------------------------------

#ifndef db01_h
#define db01_h

/*---------------------------------------*/
/* AT91DB01 External Memories Definition */
/*---------------------------------------*/

/* SSRAM emulating Internal ROM : 256K*32 */
#define SSRAM_BASE          INT_ROM_BASE
#define SSRAM_SIZE          (256*1024*4)
#define SSRAM_LIMIT         ((u_int *)(((u_int)SSRAM_BASE) + SSRAM_SIZE))

/* External Boot ROM Memory : AT27LV256A 32k*8 */
#define BOOT_ROM_BASE       ((u_int *) 0x01000000)
#define BOOT_ROM_SIZE       (32*1024)
#define BOOT_ROM_LIMIT      ((u_int *)(((u_int)BOOT_ROM_BASE) + BOOT_ROM_SIZE))

/* Flash Memory : 2 * AT29C020 128k*8 */
#define FLASH_BASE          ((u_int *)0x02000000)
#define FLASH_SIZE          (2*128*1024)
#define FLASH_LIMIT         ((u_int *)(((u_int)FLASH_BASE) + FLASH_SIZE))

/*--------------------------------*/
/* AT91DB0x Interfaces Definition */
/*--------------------------------*/

/* Green Leds */
#define LED1        P4
#define LED2        P1

/* SW1 Push Button */
#define IRQ_SW1     IRQ0
#define PIN_SW1     P9

#endif /* db01_h */
