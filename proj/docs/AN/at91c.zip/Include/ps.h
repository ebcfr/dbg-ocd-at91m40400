//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : ps.h
//* Object              : Power Saving Definition File
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* 1.0 08/01/98 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

#ifndef ps_h
#define ps_h

/*-----------------------------------*/
/* Power Saving Structure Definition */
/*-----------------------------------*/

typedef struct
{
    at91_reg    PS_CR ; /* Control Register */
} StructPS ;

/*-----------------------------------------------*/
/* Power Saving Control Register Bits Definition */
/*-----------------------------------------------*/

#define ARM7DIS         (1<<0)

/*--------------------------------*/
/* Device Dependancies Definition */
/*--------------------------------*/

#ifdef AT91M40400

#define PS_BASE         ((StructPS *) 0xFFFF4000 )

#endif /* AT91M40400 */

#endif /* ps_h */
