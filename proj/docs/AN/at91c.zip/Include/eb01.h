//*--------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*--------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : eb01.h
//* Object              : AT91 Evaluation Board Features Definition File
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* 1.0 14/09/98 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*--------------------------------------------------------------------------

#ifndef eb01_h
#define eb01_h

/*---------------------------------------*/
/* AT91EB01 External Memories Definition */
/*---------------------------------------*/

/* Flash Memory : AT29LV1024 64k*16 */
#define FLASH_BASE      ((u_int *)0x01000000)

/* SRAM : size is depending on the devices fitted on the board */
#define SRAM_BASE       ((u_int *)0x02000000)

/*--------------------------------*/
/* AT91EB01 Interfaces Definition */
/*--------------------------------*/

/* Red Led */
#define LED1        P1
/* Amber Led */
#define LED2        P4
/* Green Led */
#define LED3        P2

/* SW3 Push Button */
#define IRQ_SW3     FIQ
#define PIN_SW3     P12

/* SW4 Push Button */
#define PIN_SW4     P5

/* SW5 Push Button */
#define IRQ_SW5     IRQ0
#define PIN_SW5     P9

/*--------------*/
/* Master Clock */
/*--------------*/

#define MCK         32768000
#define MCKMHz      (MCK/1000000)

#endif /* eb01_h */
