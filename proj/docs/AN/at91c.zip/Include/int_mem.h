//*--------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*--------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : int_mem.h
//* Object              : Internal Memories Definition File
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* 1.0 08/08/98 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*--------------------------------------------------------------------------

#ifndef int_mem_h
#define int_mem.h

/*------------------------------*/
/* AT91 Internal RAM Definition */
/*------------------------------*/

#define RAM_BASE            ((u_int *)0x00000000)
#define RAM_SIZE            4096
#define RAM_LIMIT           (((u_int)RAM_BASE) + RAM_SIZE)

/*
The internal RAM is mapped at address 0x00300000 after reset until
Remap command is performed on the EBI.
*/
#define RAM_BASE_BOOT       ((u_int *)0x00300000)

/*------------------------------*/
/* AT91 Internal ROM Definition */
/*------------------------------*/
/*
No product with internal ROM is available now.
1 MBytes page is reserved for it.
Internal ROM is emulated on development boards.
*/

#define INT_ROM_BASE        ((u_int *)0x00100000)
#define MAX_INT_ROM_SIZE    (1024*1024)
#define INT_ROM_LIMIT       (((u_int)INT_ROM_BASE) + MAX_INT_ROM_SIZE)

#endif /* int_mem_h */
