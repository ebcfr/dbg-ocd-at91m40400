//*---------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*---------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : sf.h
//* Object              : Special Function Header File
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* 1.0 07/12/97 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up.
//*---------------------------------------------------------------------------

#ifndef sf_h
#define sf_h

/*-------------------------------------------------*/
/* Chip Identification Module Structure Definition */
/*-------------------------------------------------*/

typedef struct
{
    at91_reg    SF_CIDR ;       /* Chip Identification Register */
    at91_reg    SF_EXID ;       /* Chip Identification Extension */
    at91_reg    SF_RSF ;        /* Reset Status Flag */
} StructSF ;

/*----------------------------------------------*/
/* Chip Identification Register Bits Definition */
/*----------------------------------------------*/

/* Version Number */
#define VERSION         (0x1F<<0)

/* Non Volatile Program Memory Size */
#define NVPSIZ          (0x0F<<8)

/* Non Volatile Data Memory Size */
#define NVDSIZ          (0x0F<<12)

/* Volatile Data Memory Size */
#define VDSIZ           (0x0F<<16)

/* Architecture Code */
#define ARCH            (0xFF<<20)

/* Non Volatile Program Memory Type */
#define NVPTYP          (0x07<<28)

/* Extension Flag */
#define EXT             ((u_int)0x01<<31)

/*------------------------------*/
/* Reset Status Flag Definition */
/*------------------------------*/

#define EXT_RESET       0x6C
#define WD_RESET        0x53

/*--------------------------------*/
/* Device Dependancies Definition */
/*--------------------------------*/

#ifdef AT91M40400

#define SF_BASE         ((StructSF *) 0xFFF00000 )

#endif /* AT91M40400 */

#endif /* sf_h */
