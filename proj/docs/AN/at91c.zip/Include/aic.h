//*---------------------------------------------------------------------------
//*         ATMEL Microcontroller Software Support  -  ROUSSET  -
//*---------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : aic.h
//* Object              : Advanced Interrupt Controller Definition File
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* 1.0 27/10/97 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*---------------------------------------------------------------------------

#ifndef aic_h
#define aic_h

/*-------------------------------------------*/
/* Interrupt Controller Structure Definition */
/*-------------------------------------------*/

typedef struct
{
    at91_reg        AIC_SMR[32] ;       /* Source Mode Register */
    at91_reg        AIC_SVR[32] ;       /* Source Vector Register */
    at91_reg        AIC_IVR ;           /* Interrupt Vector Register */
    at91_reg        AIC_FVR ;           /* FIQ Vector Register */
    at91_reg        AIC_ISR ;           /* Interrupt Status Register */
    at91_reg        AIC_IPR ;           /* Interrupt Pending Register */
    at91_reg        AIC_IMR ;           /* Interrupt Mask Register */
    at91_reg        AIC_CISR ;          /* Core Interrupt Status Register */
    at91_reg        reserved0 ;
    at91_reg        reserved1 ;
    at91_reg        AIC_IECR ;          /* Interrupt Enable Command Register */
    at91_reg        AIC_IDCR ;          /* Interrupt Disable Command Register */
    at91_reg        AIC_ICCR ;          /* Interrupt Clear Command Register */
    at91_reg        AIC_ISCR ;          /* Interrupt Set Command Register */
    at91_reg        AIC_EOICR ;         /* End of Interrupt Command Register */
} StructAIC ;

/*---------------------------------*/
/* Interrupt Source Mode Registers */
/*---------------------------------*/

/* Source Type Definition */
#define LevelSensitive              (0<<5)
#define EdgeTriggered               (1<<5)
#define LowLevel                    (0<<5)
#define NegativeEdge                (1<<5)
#define HighLevel                   (2<<5)
#define PositiveEdge                (3<<5)

#define SRCTYPE                     (3<<5)
#define PRIOR                       (7<<0)

/*---------------------------*/
/* Interrupt Status Register */
/*---------------------------*/
#define IRQID                       0x1F

/*--------------------------------*/
/* Interrupt Core Status Register */
/*--------------------------------*/
#define NFIQ                        (1<<0)
#define NIRQ                        (1<<1)

/*---------------------------------------*/
/* AIC Interrupt Handler type definition */
/*---------------------------------------*/

typedef void (*TypeAICHandler) (void) ;

/*--------------------------------*/
/* Device Dependancies Definition */
/*--------------------------------*/

/* Advanced Interrupt Controller is always at same address for vectoring */
#define AIC_BASE            ((StructAIC *) 0xFFFFF000 )

#ifdef AT91M40400

/* Interrupt Sources Definition */

#define FIQ             0
#define SWIRQ           1
#define US0IRQ          2
#define US1IRQ          3
#define TC0IRQ          4
#define TC1IRQ          5
#define TC2IRQ          6

#define WDIRQ           7
#define PIOIRQ          8

#define IRQ0            16
#define IRQ1            17
#define IRQ2            18

/* Really implemented in the 40400 not including the FIQ */
#define NB_INTERRUPT    18

#endif /* AT91M40400 */

#endif /* aic_h */
