//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : tc.h
//* Object              : Timer Counter Definition File
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* 1.0 02/12/97 JCZ    : Creation
//* 1.1 04/06/98 JCZ    : TC_BMR fields definition added
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

#ifndef tc_h
#define tc_h

/*----------------------------*/
/* Timer Structure Definition */
/*----------------------------*/

typedef struct
{
    at91_reg        TC_CCR ;        /* Control Register */
    at91_reg        TC_CMR ;        /* Mode Register */
    at91_reg        Reserved0 ;
    at91_reg        Reserved1 ;
    at91_reg        TC_CV ;         /* Counter value */
    at91_reg        TC_RA ;         /* Register A */
    at91_reg        TC_RB ;         /* Register B */
    at91_reg        TC_RC ;         /* Register C */
    at91_reg        TC_SR ;         /* Status Register */
    at91_reg        TC_IER ;        /* Interrupt Enable Register */
    at91_reg        TC_IDR ;        /* Interrupt Disable Register */
    at91_reg        TC_IMR ;        /* Interrupt Mask Register */
    at91_reg        Reserved2 ;
    at91_reg        Reserved3 ;
    at91_reg        Reserved4 ;
    at91_reg        Reserved5 ;
} StructTC ;

#define NB_TC_CHANNEL       3

typedef struct
{
    StructTC        TC[NB_TC_CHANNEL] ;
    at91_reg        TC_BCR ;        /* Block Control Register */
    at91_reg        TC_BMR ;        /* Block Mode Register  */
} StructTCBlock ;

/*------------------------------------------------*/
/* Timer Counter Control Register Bits Definition */
/*------------------------------------------------*/
#define CLKEN           (1<<0)
#define CLKDIS          (1<<1)
#define SWTRG           (1<<2)

/*---------------------------------------------*/
/* Timer Counter Mode Register Bits Definition */
/*---------------------------------------------*/
/* Edges Definition */
#define EdgeNone        ((u_int)0)
#define RisingEdge      ((u_int)1)
#define FallingEdge     ((u_int)2)
#define BothEdge        ((u_int)3)

/* Output Control Definition */
#define OutputNone      ((u_int)0)
#define SetOutput       ((u_int)1)
#define ClearOutput     ((u_int)2)
#define ToggleOutput    ((u_int)3)

/* Clock Selection */
#define TCCLKS          (7<<0)
#define TCMCK2          (0<<0)
#define TCMCK8          (1<<0)
#define TCMCK32         (2<<0)
#define TCMCK128        (3<<0)
#define TCMCK1024       (4<<0)
#define TCXc0           (5<<0)
#define TCXc1           (6<<0)
#define TCXc2           (7<<0)

/* Clock Inversion */
#define CLKI            (1<<3)

/* Burst Signal Selection */
#define BURST           (3<<4)
#define BurstNone       (0<<4)
#define BurstXc0        (1<<4)
#define BurstXc1        (2<<4)
#define BurstXc2        (3<<4)

/* Capture Mode : Counter Clock Stopped with RB Loading */
#define LDBSTOP         (1<<6)
/* Waveform Mode : Counter Clock Stopped with RC Compare */
#define CPCSTOP         (1<<6)

/* Capture Mode : Counter Clock Disabled with RB Loading */
#define LDBDIS          (1<<7)
/* Waveform Mode : Counter Clock Disabled with RC Compare */
#define CPCDIS          (1<<7)

/* Capture Mode : External Trigger Edge Selection */
#define B_ETRGEDG       8
#define ETRGEDG         (3<<B_ETRGEDG)
/* Waveform Mode : External Event Edge Selection */
#define B_EEVTEDG       8
#define EEVTEDG         (3<<B_EEVTEDG)

/* Capture Mode : TIOA or TIOB External Trigger Selection */
#define ABETRG          (1<<10)
/* Waveform Mode : External Event Selection */
#define B_EEVT          10
#define EEVT            (3<<B_EEVT)
#define EEVTTiob        (0<<B_EEVT)
#define EEVTXc0         (1<<B_EEVT)
#define EEVTXc1         (2<<B_EEVT)
#define EEVTXc2         (3<<B_EEVT)

/* Waveform Mode : Enable Trigger on External Event */
#define ENETRG          (1<<12)

/* RC Compare Enable Trigger Enable */
#define CPCTRG          (1<<14)

/* Mode Selection */
#define WAVE            (1<<15)
#define CAPT            (0<<15)

/* Capture Mode : RA Loading Selection */
#define B_LDRA          16
#define LDRA            (3<<B_LDRA)
/* Waveform Mode : RA Compare Effect on TIOA */
#define B_ACPA          16
#define ACPA            (3<<B_ACPA)

/* Capture Mode : RB Loading Selection */
#define B_LDRB          18
#define LDRB            (3<<B_LDRB)
/* Waveform Mode : RC Compare Effect on TIOA */
#define B_ACPC          18
#define ACPC            (3<<B_ACPC)

/* Waveform Mode : External Event Effect on TIOA */
#define B_AEEVT         20
#define AEEVT           (3<<B_AEEVT)

/* Waveform Mode : Software Trigger Effect on TIOA */
#define B_ASWTRG        22
#define ASWTRG          (3<<B_ASWTRG)

/* Waveform Mode : RB Compare Effect on TIOB */
#define B_BCPB          24
#define BCPB            (3<<B_BCPB)

/* Waveform Mode : RC Compare Effect on TIOB */
#define B_BCPC          26
#define BCPC            (3<<B_BCPC)

/* Waveform Mode : External Event Effect on TIOB */
#define B_BEEVT         28
#define BEEVT           (3<<B_BEEVT)

/* Waveform Mode : Software Trigger Effect on TIOB */
#define B_BSWTRG        30
#define BSWTRG          (((u_int)3)<<B_BSWTRG)

/*-----------------------------------------------*/
/* Timer Counter Status Register Bits Definition */
/*-----------------------------------------------*/
/* Counter Overflow Status */
#define COVFS           (1<<0)
/* Load Overrun Status */
#define LOVRS           (1<<1)
/* RA Compare Status */
#define CPAS            (1<<2)
/* RB Compare Status */
#define CPBS            (1<<3)
/* RC Compare Status */
#define CPCS            (1<<4)
/* RA Loading Status */
#define LDRAS           (1<<5)
/* RB Loading Status */
#define LDRBS           (1<<6)
/* External Trigger Status */
#define ETRGS           (1<<7)
/* Clock Status */
#define CLKSTA          (1<<16)
/* TIOA Mirror */
#define MTIOA           (1<<17)
/* TIOB Status */
#define MTIOB           (1<<18)

/*------------------------------------------------------*/
/* Timer Counter Block Control Register Bits Definition */
/*------------------------------------------------------*/
/* Synchronisation Trigger */
#define TCSYNC          1

/*---------------------------------------------------*/
/* Timer Counter Block Mode Register Bits Definition */
/*---------------------------------------------------*/
#define B_TC0XC0S       0
#define TC0XC0S         (3<<B_TC0XC0S)

#define TCLK0XC0        (0<<B_TC0XC0S)
#define NONEXC0         (1<<B_TC0XC0S)
#define TIOA1XC0        (2<<B_TC0XC0S)
#define TIOA2XC0        (3<<B_TC0XC0S)

#define B_TC1XC1S       2
#define TC1XC1S         (3<<B_TC1XC1S)

#define TCLK1XC1        (0<<B_TC1XC1S)
#define NONEXC1         (1<<B_TC1XC1S)
#define TIOA0XC1        (2<<B_TC1XC1S)
#define TIOA2XC1        (3<<B_TC1XC1S)

#define B_TC2XC2S       4
#define TC2XC2S         (3<<B_TC2XC2S)

#define TCLK2XC2        (0<<B_TC2XC2S)
#define NONEXC2         (1<<B_TC2XC2S)
#define TIOA0XC2        (2<<B_TC2XC2S)
#define TIOA1XC2        (3<<B_TC2XC2S)

/*---------------------------------------*/
/* Timer Counter Handler type definition */
/*---------------------------------------*/

typedef void (*TypeTCHandler) ( StructTC *tc_pt ) ;

/*--------------------------------*/
/* Device Dependancies Definition */
/*--------------------------------*/

#ifdef AT91M40400

#define NB_TC_BLOCK     1
#define NB_TIMER        (NB_TC_BLOCK*NB_TC_CHANNEL)
#define TCB0_BASE       ((StructTCBlock *)0xFFFE0000)

#endif /* AT91M40400 */

#endif /* tc_h */

