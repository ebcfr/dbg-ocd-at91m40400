//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : wd.h
//* Object              : Watch Dog Definition File
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* 1.0 03/12/97 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------
#ifndef wd_h
#define wd_h

/*------------------------------------------*/
/* Watch Dog Interface Structure Definition */
/*------------------------------------------*/
typedef struct
{
    at91_reg        WD_OMR ;        /* Overflow Mode Register */
    at91_reg        WD_CMR ;        /* Clock Mode Register */
    at91_reg        WD_CR ;         /* Control Register */
    at91_reg        WD_SR ;         /* Status Register */
    at91_reg        Reserved ;
    at91_reg        WD_TLR ;        /* Test Load Register : test purpose only */
} StructWD ;

/*--------------------------------------------------*/
/* Watch Dog Overflow Mode Register Bits Definition */
/*--------------------------------------------------*/

/* Watch Dog Enable */
#define WDEN            (1<<0)

/* Internal Reset Enable */
#define RSTEN           (1<<1)

/* Interrupt Enable */
#define IRQEN           (1<<2)

/* External Signal Enable */
#define EXTEN           (1<<3)

/* Overflow Mode Register Access Key */
#define OKEY            (0x234<<4)

/*------------------------------------------*/
/* Watch Dog Clock Register Bits Definition */
/*------------------------------------------*/

/* Clock Selection */
#define WDCLKS          (3<<0)
#define WDClk8          (0<<0)
#define WDClk32         (1<<0)
#define WDClk128        (2<<0)
#define WDClk1024       (3<<0)

/* Hicg Preload Counter Value */
#define HPCV            (0xF<<2)

/* Clock Register Access Key */
#define CKEY            (0x06E<<7)

/*--------------------------------------------*/
/* Watch Dog Control Register Bits Definition */
/*--------------------------------------------*/

/* Watch Dog Restart Key */
#define RSTKEY          0xC071

/*-------------------------------------------*/
/* Watch Dog Status Register Bits Definition */
/*-------------------------------------------*/

/* WatchDog Overflow Status */
#define WDOVF           (1<<0)

/*-----------------------------------*/
/* Watch Dog Handler type definition */
/*-----------------------------------*/

typedef void (*TypeWDHandler) ( void ) ;

/*--------------------------------*/
/* Device Dependancies Definition */
/*--------------------------------*/

#ifdef AT91M40400

#define WD_BASE         (( StructWD *) 0xFFFF8000 )

#endif /* AT91M40400 */

#endif /* wd_h */
