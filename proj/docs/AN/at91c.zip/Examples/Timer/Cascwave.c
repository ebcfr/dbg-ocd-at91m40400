#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : Cascwave.c
//* Object              : AT91 - Timer Counter - Timers Cascade
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : None
//* Exported resources  : MainApplication
//*
//* 1.0 30/09/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------
/*
Configure the channel 0 of the Timer Counter (TC) of the AT91
to aim Single waveform generation :
- clock = MCKI / 1024
- Register C = 0x4000
  toggle TIOA0 when reached
  generate trigger to restart the timer

Configure the channel 1 of the Timer Counter (TC) of the AT91
to aim single waveform generation by using TIOA0 as clock :
- clock = XC1
- Register C = 0x0001
  toggle TIOA0 and TIOB0 when reached
  generate trigger to restart the timer

Every time the user button is pressed, the clock is inverted :
--------------------------------------------------------------------------------
          _   _   _   _   _   _   _   _   _   _   _   _   _
  TIOA0 _| |_| |_| |_| |_| |_| |_| |_| |_| |_| |_| |_| |_|     red LED / output
          _______         _______       _______         ___
  TIOA1 _|       |_______|       |_____|       |_______|     amber LED / output
                                   _
  TIOB1 __________________________| |______________________  input
--------------------------------------------------------------------------------
*/

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/
/* None */

/*----- Types and Constants Definition -----*/
#define AT91_REG(x) (*(volatile unsigned long *)(x))

/*----- Imported Resources Definition -----*/
/* None */

/*---- Internal Resources Definition -----*/

static __irq void ItTimer1 ( void )
{
   // Invert TIOA1 every time TIOB1 is pressed
    AT91_REG(0xFFFE0044) ^= (1 << 3);
    // Acknowledge at timer level
    AT91_REG(0xFFFFF130) = AT91_REG(0xFFFE0060);
}

/*---- External Resources Definition -----*/
#define _REFERENCE(x)   x
#define CORPS
#endif


//*-----------------------------------------------------------------------------
//* Function Name       : MainApplication
//* Object              : AT91 - Timer Counter - Timers Cascade
//* Input Parameters    : none
//* Output Parameters   : none
//* Functions called    : None
//*-----------------------------------------------------------------------------
_REFERENCE (int MainApplication( void ))
#ifdef CORPS
//* Begin
{
    long dummy;

    // Define the PIO :
    // . TIOA0 and TIOA1 and TIOB1 as peripheral
    AT91_REG(0xFFFF0004) = 0x00000032;

    // Define XC1 as TIOA0 for channel 0
    AT91_REG(0xFFFE00C4) = 0x0008;

    // Initialize timer 1 interrupt
    // . interrupt handler address
    AT91_REG(0xFFFFF094) = ((unsigned long)ItTimer1);
    // . Source Mode Register
    AT91_REG(0xFFFFF014) =
        (1 << 5) |          // Edge triggered
        (1 << 0);           // Priority 1
    // . Enable the interrupt
    AT91_REG(0xFFFFF120) = (1 << 5);

    // Initialize the mode of the channel 1
    AT91_REG(0xFFFE0044) =
        (1 << 22) |         // ASWTRG  : software trigger set TIOA
        (3 << 18) |         // ACPC    : Register C compare toggle TIOA
        (1 << 15) |         // WAVE    : Waveform mode
        (1 << 14) |         // CPCTRG  : Register C compare trigger enable
        (1 << 12) |         // ENETRG  : External event trigger enable
        (0 << 10) |         // EEVT    : TIOB as external event
        (1 << 8) |          // EEVTEDG : Trigger on rising edge
        (6 << 0) ;          // TCCLKS  : XC1
    // Validate interrupts
    dummy = AT91_REG(0xFFFE0060);
    AT91_REG(0xFFFE0064) = (1 << 7);    // External trigger
    // Initialize the RC Register value
    AT91_REG(0xFFFE005C) = 0x0001;

    // Start the timer 1
    // . Enable the clock
    AT91_REG(0xFFFE0040) = 0x0001;
    // . Trig
    AT91_REG(0xFFFE0040) = 0x0004;

    // Initialize the mode of the timer 0
    AT91_REG(0xFFFE0004) =
        (1 << 22) |         // ASWTRG  : software trigger set TIOA
        (3 << 18) |         // ACPC    : Register C compare toggle TIOA
        (1 << 15) |         // WAVE    : Waveform mode
        (1 << 14) |         // CPCTRG  : Register C compare trigger enable
        (4 << 0) ;          // TCCLKS  : MCKI / 1024
    // Initialize the RC value
    AT91_REG(0xFFFE001C) = 0x4000;

    // Start the timer 0
    // . Enable the clock
    AT91_REG(0xFFFE0000) = 0x0001;
    // . Trig
    AT91_REG(0xFFFE0000) = 0x0004;

    for (;;)
    {
    }

//* End
    return(0);
}
#endif
