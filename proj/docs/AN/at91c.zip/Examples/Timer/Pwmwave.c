#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : Pwmwave.c
//* Object              : AT91 - Timer Counter - PWM generation
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : None
//* Exported resources  : MainApplication
//*
//* 1.0 30/09/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------
/*
Configure the channel 0 of the Timer Counter(TC) of the AT91
to aim dual waveform generation :
- clock = MCKI / 2
- Register A toggle TIOA0 when reached
- Register B toggle TIOB0 when reached
- Register C = 0xF000
  toggle TIOA0 and TIOB0 when reached
  generate trigger to restart the timer
When pushing on FIQ (P12) :
- red LED switches on
- green LED switches off
When pushing on IRQ0 (P9) :
- red LED switches off
- green LED switches on
--------------------------------------------------------------------------------
At start-up :
           ________          ________          ______
  TIOA0 __|        |________|        |________|             red LED / output
           ________          ________          ______
  TIOB0 __|        |________|        |________|           green LED / output

When pushing IRQ0 :
           ____ <<           ____              ______
  TIOA0 __|    |____________|    |____________|             red LED / output
           ____________      ____________      ______
  TIOB0 __|          >>|____|            |____|           green LED / output

When pushing FIQ :
           ____________      ____________      ______
  TIOA0 __|          >>|____|            |____|             red LED / output
           ____ <<           ____              ______
  TIOB0 __|    |____________|    |____________|           green LED / output
--------------------------------------------------------------------------------
*/

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/
/* None */

/*----- Types and Constants Definition -----*/
#define AT91_REG(x) (*(volatile unsigned long *)(x))

/*----- Imported Resources Definition -----*/
/* None */

/*---- Internal Resources Definition -----*/

static unsigned long status;

static __irq void ItTimer0 ( void )
{
    // Acknowledge at timer level
    status = AT91_REG(0xFFFFF130) = AT91_REG(0xFFFE0020);
}

/*---- External Resources Definition -----*/
#define _REFERENCE(x)   x
#define CORPS
#endif

//*-----------------------------------------------------------------------------
//* Function Name       : MainApplication
//* Object              : AT91 - Timer Counter- PWM generation
//* Input Parameters    : none
//* Output Parameters   : none
//* Functions called    : None
//*-----------------------------------------------------------------------------
_REFERENCE (int MainApplication( void ))
#ifdef CORPS
//* Begin
{
    unsigned long pwm;
    long value;

    // Clear PIO output corresponding to TIOA0, TIOB0 and TIOA1
    AT91_REG(0xFFFF0000) = 0x00000016;
    AT91_REG(0xFFFF0010) = 0x00000016;
    AT91_REG(0xFFFF0034) = 0x00000016;

    // Define TIOA0 and TIOB as peripheral
    AT91_REG(0xFFFF0004) = 0x0006;
    // Define IRQ0 and FIQ as PIO
    AT91_REG(0xFFFF0000) = 0x00001200;

    // Initialize timer 0 interrupt
    // . interrupt handler address
    AT91_REG(0xFFFFF090) = ((unsigned long)ItTimer0);
    // . Source Mode Register
    AT91_REG(0xFFFFF010) =
        (1 << 5) |          // Edge triggered
        (1 << 0);           // Priority 1
    // . Enable the interrupt
    AT91_REG(0xFFFFF120) = (1 << 4);

    // Initialize the mode of the timer 0
    AT91_REG(0xFFFE0004) =
        (1 << 30) |         // BSWTRG  : software trigger set TIOB
        (1 << 26) |         // BCPC    : Register C compare set TIOB
        (2 << 24) |         // BCPA    : Register B compare clear TIOB
        (1 << 22) |         // ASWTRG  : software trigger set TIOA
        (1 << 18) |         // ACPC    : Register C compare set TIOA
        (2 << 16) |         // ACPA    : Register A compare clear TIOA
        (1 << 15) |         // WAVE    : Waveform mode
        (1 << 14) |         // CPCTRG  : Register C compare trigger enable
        (1 << 10) |         // EEVT    : XC0 as external event (TIOB = output)
        (1 << 0) ;          // TCCLKS  : MCKI / 2
    // Validate interrupts
    status = AT91_REG(0xFFFE0020);
    AT91_REG(0xFFFE0024) = (1 <<4); // RC compare

    // Initialize the counters :
    // . Register C
    AT91_REG(0xFFFE001C) = 0xF000;

    // Start the timer :
    // . Enable the clock
    AT91_REG(0xFFFE0000) = 0x0001;
    // . Trig the timer
    AT91_REG(0xFFFE0000) = 0x0004;

   // Invert TIOA1 every time TIOB1 is pressed
    pwm = 0x0400;
    value = 0x00004000;
    for (;;)
    {
        // Check if interrupt received
        if (status != 0)
        {
            status = 0;
            // Check if PIO12 pressed
            if (((AT91_REG(0xFFFF003C) & 0x00001000) != 0) &&
                    (AT91_REG(0xFFFE0014) < (AT91_REG(0xFFFE001C)-1)))
            {
                if ((value = AT91_REG(0xFFFE0014) + pwm) >= AT91_REG(0xFFFE001C))
                {
                    value = AT91_REG(0xFFFE001C) - 1;
                }
            }

            // Check if PIO9 pressed
            if (((AT91_REG(0xFFFF003C) & 0x00000200) != 0) &&
                    (AT91_REG(0xFFFE0014) > 1))
            {
                if ((value = AT91_REG(0xFFFE0014) - pwm) <= 0)
                {
                    value = 1;
                }
            }
        }
        if (value != 0)
        {
            AT91_REG(0xFFFE0014) = value;
            AT91_REG(0xFFFE0018) = AT91_REG(0xFFFE001C) - value;
            value = 0;
        }
    }

//* End
    return(0);
}
#endif
