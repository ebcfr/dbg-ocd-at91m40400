#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : Singwave.c
//* Object              : AT91 - Timer Counter - Single waveform generation
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : None
//* Exported resources  : MainApplication
//*
//* 1.0 30/09/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

/*
Configure the channel 1 of the Timer Counter (TC) of the AT91
to aim Single waveform generation with trigger on TIOB1 :
- clock = MCKI / 1024
- Register A = 0x6000
  toggle TIOA1 when reached
- Register C = 0x8000
  toggle TIOA1 when reached
  generate trigger to restart the timer
- External event on TIOB1
  toggle TIOA1 on falling edge
  generate trigger to restart the timer
Every time the user button is pressed :
- the duty cycle is inverted
- red and green LEDs are inverted
--------------------------------------------------------------------------------
        __________   ____   _____________
  TIOB1           |_|    |_|               user switch
          ____   _      _   ____
  TIOA1 _|    |_| |____| |_|    |________  amber LED
        __________          _____________
                  |________|               green LED
                   ________
        __________|        |_____________  red LED
--------------------------------------------------------------------------------
*/

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/
/* None */

/*----- Types and Constants Definition -----*/
#define AT91_REG(x) (*(volatile unsigned long *)(x))

/*----- Imported Resources Definition -----*/
/* None */

/*---- Internal Resources Definition -----*/

static __irq void ItTimer1 ( void )
{
    // Invert red LED
    if ((AT91_REG(0xFFFF0038) & (1 << 1)) != 0)
    {
        AT91_REG(0xFFFF0030) = (1 << 2);
        AT91_REG(0xFFFF0034) = (1 << 1);
    }
    else
    {
        AT91_REG(0xFFFF0030) = (1 << 1);
        AT91_REG(0xFFFF0034) = (1 << 2);
    }
    // Acknowledge at timer level
    AT91_REG(0xFFFFF130) = AT91_REG(0xFFFE0060);
}

/*---- External Resources Definition -----*/
#define _REFERENCE(x)   x
#define CORPS
#endif

//*-----------------------------------------------------------------------------
//* Function Name       : MainApplication
//* Object              : AT91 - Timer Counter - Single waveform generation
//* Input Parameters    : none
//* Output Parameters   : none
//* Functions called    : None
//*-----------------------------------------------------------------------------
_REFERENCE (int MainApplication( void ))
#ifdef CORPS
//* Begin
{
    long dummy;

    // Clear PIO output corresponding to TIOA0, TIOB0 and TIOA1
    AT91_REG(0xFFFF0000) = 0x00000016;
    AT91_REG(0xFFFF0010) = 0x00000016;
    AT91_REG(0xFFFF0034) = 0x00000016;

    // Define TIOA0 and TIOB0 as PIO output
    AT91_REG(0xFFFF0000) = AT91_REG(0xFFFF0010) = 0x00000006;
    // . switch ON green LED
    AT91_REG(0xFFFF0030) = (1 << 2);
    // . switch OFF red LED
    AT91_REG(0xFFFF0034) = (1 << 1);
    // Define TIOA1 and TIOB1 as peripheral
    AT91_REG(0xFFFF0004) = 0x00000030;

    // Initialize timer 1 interrupt
    // . interrupt handler address
    AT91_REG(0xFFFFF094) = ((unsigned long)ItTimer1);
    // . Source Mode Register
    AT91_REG(0xFFFFF014) =
        (1 << 5) |          // Edge triggered
        (1 << 0);           // Priority 1
    // . Enable the interrupt
    AT91_REG(0xFFFFF120) = (1 << 5);

    // Initialize the mode of the channel 1
    AT91_REG(0xFFFE0044) =
        (1 << 22) |         // ASWTRG  : software trigger set TIOA
        (3 << 20) |         // AEEVT   : external event toggle TIOA
        (3 << 18) |         // ACPC    : Register C compare toggle TIOA
        (3 << 16) |         // ACPA    : Register A compare toggle TIOA
        (1 << 15) |         // WAVE    : Waveform mode
        (1 << 14) |         // CPCTRG  : Register C compare trigger enable
        (1 << 12) |         // ENETRG  : External event trigger enable
        (0 << 10) |         // EEVT    : TIOB as external event
        (2 << 8) |          // EEVTEDG : Trigger on falling edge
        (4 << 0) ;          // TCCLKS  : MCKI / 1024
    // Validate interrupts
    dummy = AT91_REG(0xFFFE0060);
    AT91_REG(0xFFFE0064) = (1 << 7);    // External trigger

    // Initialize the counters
    // . Register A
    AT91_REG(0xFFFE0054) = 0x6000;
    // . Register C
    AT91_REG(0xFFFE005C) = 0x8000;

    // Enable the clock of the timer
    AT91_REG(0xFFFE0040) = 0x0001;

    // Trig the timer
    AT91_REG(0xFFFE0040) = 0x0004;
    for (;;)
    {
    }

//* End
    return(0);
}
#endif
