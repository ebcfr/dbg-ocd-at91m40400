#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : Brstwave.c
//* Object              : AT91 - Timer Counter - Burst waveform generation
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : None
//* Exported resources  : MainApplication
//*
//* 1.0 30/09/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------
/*
Configure the channel 0 of the Timer Counter (TC) of the AT91
to aim Single waveform generation :
- clock = MCKI / 1024
- Register C = 0xA000
  toggle TIOA1 when reached
  generate trigger to restart the timer

Configure the channel 1 of the Timer Counter (TC) of the AT91
to aim single waveform generation by anding the clock with TIOA1 :
- clock = MCKI / 1024 ANDed with XC1 (TIOA0)
- Register C = 0x4000
  toggle TIOA1 when reached
  generate trigger to restart the timer
--------------------------------------------------------------------------------
          ___     ___     ___     ___     ___     ___     _
  TIOA0 _|   |___|   |___|   |___|   |___|   |___|   |___|     red LED / output
          _   ___   _     _   ___   _     _   ___   _     _
  TIOA1 _| |_|   |_| |___| |_|   |_| |___| |_|   |_| |___|   amber LED / output
--------------------------------------------------------------------------------
*/

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/
/* None */

/*----- Types and Constants Definition -----*/

#define AT91_REG(x) (*(volatile unsigned long *)(x))

/*----- Imported Resources Definition -----*/
/* None */

/*---- Internal Resources Definition -----*/
/* None */

/*---- External Resources Definition -----*/
#define _REFERENCE(x)   x
#define CORPS
#endif

//*-----------------------------------------------------------------------------
//* Function Name       : MainApplication
//* Object              : AT91 - Timer Counter - Burst waveform generation
//* Input Parameters    : none
//* Output Parameters   : none
//* Functions called    : None
//*-----------------------------------------------------------------------------
_REFERENCE (int MainApplication( void ))
#ifdef CORPS
//* Begin
{
    // Clear PIO output corresponding to TIOA0, TIOB0 and TIOA1
    AT91_REG(0xFFFF0000) = 0x00000016;
    AT91_REG(0xFFFF0010) = 0x00000016;
    AT91_REG(0xFFFF0034) = 0x00000016;

    // Define XC1 as TIOA0 for channel 0
    AT91_REG(0xFFFE00C4) = 0x0008;

    // Define TIOA1 as peripheral
    AT91_REG(0xFFFF0004) = 0x00000010;
    // Disable the timer 1
    AT91_REG(0xFFFE0040) = 0x0002;
    // Initialize the mode of the channel 1
    AT91_REG(0xFFFE0044) =
        (1 << 22) |         // ASWTRG  : software trigger set TIOA
        (3 << 18) |         // ACPC    : Register C compare toggle TIOA
        (1 << 15) |         // WAVE    : Waveform mode
        (1 << 14) |         // CPCTRG  : Register C compare trigger enable
        (2 << 4) |          // BURST   : XC1 is ANDed with the selected clock
        (4 << 0) ;          // TCCLKS  : MCKI / 1024
    // Initialize the RC Register value
    AT91_REG(0xFFFE005C) = 0x4000;
    // Enable the clock of the timer
    AT91_REG(0xFFFE0040) = 0x0001;
    // Trig the timer
    AT91_REG(0xFFFE0040) = 0x0004;

    // Define TIOA0 as peripheral
    AT91_REG(0xFFFF0004) = 0x0002;
    // Disable the timer 0
    AT91_REG(0xFFFE0000) = 0x0002;
    // Initialize the mode of the timer 0
    AT91_REG(0xFFFE0004) =
        (1 << 22) |         // ASWTRG  : software trigger set TIOA
        (3 << 18) |         // ACPC    : Register C compare toggle TIOA
        (1 << 15) |         // WAVE    : Waveform mode
        (1 << 14) |         // CPCTRG  : Register C compare trigger enable
        (4 << 0) ;          // TCCLKS  : MCKI / 1024
    // Initialize the RC Register value
    AT91_REG(0xFFFE001C) = 0xA000;
    // Enable the clock of the timer
    AT91_REG(0xFFFE0000) = 0x0001;
    // Trig the timer
    AT91_REG(0xFFFE0000) = 0x0004;

//* End
    return(0);
}
#endif
