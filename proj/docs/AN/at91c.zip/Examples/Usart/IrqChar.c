#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : IrqChar.c
//* Object              : AT91 - USART Controller - Characters / Interrupt
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : init_usart - disable_usart - enable_usart_irq
//* Exported resources  : MainApplication
//*
//* 1.0 01/10/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*----------------------------------------------------------------------------
/*
Configure the USART 0 of the AT91 to send and receive bytes on the channel 1
set with local loopback mode.
The TxRDY interrupt is enabled in order to send byte, then disabled until the
reception of the byte, which is detected by interrupt when RxRDY is set.
The byte format is : start + 8 data (without parity) + 1 stop
The baud rate is counter is 53 : 38400 bauds with MCKI = 32.768 MHz
The byte transferred is incremented by one
*/

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#ifndef AT91_DEBUG_NONE
#include <stdio.h>
#endif
#include "../../Include/std_c.h"        /* Standard C Types */
#include "../../Include/usart.h"
#include "../../Include/eb01.h"


/*----- Types and Constants Definition -----*/
#define AT91_REG(x) (*(volatile unsigned int *)(x))

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;

#include    "../../Library/lib_usart.c" /* Usart Library */

#undef _REFERENCE

/*---- Internal Resources Definition -----*/

static int  value_tx;
static int  value_rx;

//*----------------------------------------------------------------------------
//* Function Name       : handle_rx
//* Object              : AT91 - USART Controller - Rx interrupt handler
//* Input Parameters    :
//*     - usart_pt (StructUSART *) - address of the USART channel
//* Output Parameters   : None
//* Functions called    : None
//*----------------------------------------------------------------------------
static void (handle_rx) ( StructUSART *usart_pt )
{
    value_rx = usart_pt->US_RHR ;
}

//*----------------------------------------------------------------------------
//* Function Name       : handle_tx
//* Object              : AT91 - USART Controller - Tx interrupt handler
//* Input Parameters    :
//*     - usart_pt (StructUSART *) - address of the USART channel
//* Output Parameters   : None
//* Functions called    : None
//*----------------------------------------------------------------------------
static void (handle_tx) ( StructUSART *usart_pt )
{
    if (value_tx >= 0)
    {
        usart_pt->US_THR = value_tx;
        value_tx = -1;
    }
    else
    {
        usart_pt->US_IDR = TXRDY;
    }
}

/*---- External Resources Definition -----*/
#define _REFERENCE(x)   x
#define CORPS
#endif

//*----------------------------------------------------------------------------
//* Function Name       : MainApplication
//* Object              : AT91 - USART Controller - characters / interrupt
//* Input Parameters    : None
//* Output Parameters   : None
//* Functions called    : init_usart - disable_usart - enable_usart_irq
//*----------------------------------------------------------------------------
_REFERENCE (int MainApplication( void ))
#ifdef CORPS
//* Begin
{
    unsigned int    loop_count;

    //* Stop channel 1
    disable_usart(1);
    for (loop_count = 1000 ; loop_count > 0 ; loop_count--);

    //* Initialize channel 1
    init_usart(1, StandardAsyncMode | LocalLoopback, ((MCK / 16) / 38400), 0);
    for (loop_count = 1000 ; loop_count > 0 ; loop_count--);

    // * Enable interrupt
    value_tx = value_rx = -1;
    enable_usart_irq (1, RXRDY, handle_rx);

    for ( ; ; )
    {
        value_tx = (value_rx + 1) & 0x00FF;
        value_rx = -1;
#ifndef AT91_DEBUG_NONE
        if (value_tx == 0)
        {
            loop_count ++ ;
            printf ( "Loop %d\n", loop_count ) ;
        }
#endif
        //* Enable transmission
        enable_usart_irq (1, TXRDY, handle_tx);
        //* Wait byte received
        for ( ; value_rx == -1 ; );
    }

//* End
    return(0);
}
#endif
