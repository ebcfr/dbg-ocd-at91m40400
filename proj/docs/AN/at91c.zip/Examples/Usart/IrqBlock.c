#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : IrqBlock.c
//* Object              : AT91 - USART Controller - Blocks with Interrupt
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : init_usart - disable_usart - enable_usart_irq
//* Exported resources  : MainApplication
//*
//* 1.0 01/10/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*----------------------------------------------------------------------------
/*
Configure the USART 0 of the AT91 to send and receive blocks on the channel 1
set with local loopback mode.
The TxEMPTY interrupt is enabled in order to send block, then disabled until the reception of the block, which is detected by interrupt when TIMEOUT is set.
The byte format is : start + 8 data (without parity) + 1 stop
The baud rate is counter is 53 : 38400 bauds with MCKI = 32.768 MHz
The block transferred is fully incremented by one
*/

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#ifndef AT91_DEBUG_NONE
#include <stdio.h>
#endif
#include "../../Include/std_c.h"        /* Standard C Types */
#include "../../Include/usart.h"
#include "../../Include/eb01.h"


/*----- Types and Constants Definition -----*/

#define AT91_REG(x) (*(volatile unsigned int *)(x))
#define INDEX_TX    0
#define INDEX_RX    1
#define FLAG_TX     (1 << INDEX_TX)
#define FLAG_RX     (1 << INDEX_RX)
#define SIZE_BLOC   128

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;

#include    "../../Library/lib_usart.c" /* Usart Library */

#undef _REFERENCE

/*---- Internal Resources Definition -----*/

static int  flag;
static char block[2][SIZE_BLOC];

//*----------------------------------------------------------------------------
//* Function Name       : handle_rx
//* Object              : AT91 - USART Controller - Rx interrupt handler
//* Input Parameters    :
//*     - usart_pt (StructUSART *) - address of the USART channel
//* Output Parameters   :
//* Functions called    : None
//*----------------------------------------------------------------------------
static void (handle_rx) ( StructUSART *usart_pt )
{
    flag &= ~FLAG_RX;
    disable_usart_irq (1, (ENDRX | TIMEOUT));
}

//*----------------------------------------------------------------------------
//* Function Name       : handle_tx
//* Object              : AT91 - USART Controller - Tx interrupt handler
//* Input Parameters    :
//*     - usart_pt (StructUSART *) - address of the USART channel
//* Output Parameters   :
//* Functions called    : None
//*----------------------------------------------------------------------------
static void (handle_tx) ( StructUSART *usart_pt )
{
    //* If transmission not done
    if ((flag & FLAG_TX) != 0)
    {
        //* Validate reception
        receive_frame (1, block[INDEX_RX], SIZE_BLOC, 8);
        enable_usart_irq (1, (ENDRX | TIMEOUT), handle_rx);
        send_frame (1, block[INDEX_TX], SIZE_BLOC / 2);
        flag &= ~FLAG_TX;
    }
    else
    {
        //* Disable transmission
        disable_usart_irq (1, ENDTX);
    }
}

/*---- External Resources Definition -----*/
#define _REFERENCE(x)   x
#define CORPS
#endif

//*----------------------------------------------------------------------------
//* Function Name       : MainApplication
//* Object              : AT91 - USART Controller - blocks with interrupt
//* Input Parameters    : none
//* Output Parameters   : none
//* Functions called    : init_usart - disable_usart - enable_usart_irq
//*----------------------------------------------------------------------------
_REFERENCE (int MainApplication( void ))
#ifdef CORPS
//* Begin
{
    unsigned int    loop_count;

    //* Stop channel 1
    disable_usart(1);
    for (loop_count = 1000 ; loop_count > 0 ; loop_count--);

    //* Initialize channel 1
    init_usart(1, StandardAsyncMode | LocalLoopback, ((MCK / 16) / 38400), 0);
    for (loop_count = 1000 ; loop_count > 0 ; loop_count--);

    // * Enable interrupt
    for (flag = 0 ; flag < SIZE_BLOC ; flag++)
    {
        block[INDEX_TX][flag] = flag;
    }

    for ( ; ; )
    {
#ifndef AT91_DEBUG_NONE
        if ((block[INDEX_TX][0] & 0x3F) == 0)
        {
            loop_count ++ ;
            printf ( "Loop %d\n", loop_count ) ;
        }
#endif
        for (flag = 0 ; flag < SIZE_BLOC ; flag++)
        {
            block[INDEX_TX][flag]++;
        }
        flag = FLAG_RX | FLAG_TX;
        //* Enable transmission
        enable_usart_irq (1, ENDTX, handle_tx);
        //* Wait block received
        for ( ; flag != 0 ; );
#ifndef AT91_DEBUG_NONE
        for (flag = 0 ; flag < (SIZE_BLOC / 2) ; flag++)
        {
            if (block[INDEX_TX][flag] != block[INDEX_RX][flag])
            {
                printf ("**** 0x%x : 0x%x / 0x%x\n", flag,
                        block[INDEX_TX][flag], block[INDEX_RX][flag]);
            }
        }
        for ( ; flag < SIZE_BLOC ; flag++)
        {
            if (block[INDEX_RX][flag] != 0)
            {
                printf ("**** 0x%x : 0x00 / 0x%x\n", flag,
                        block[INDEX_RX][flag]);
            }
        }
#endif
    }

//* End
    return(0);
}
#endif
