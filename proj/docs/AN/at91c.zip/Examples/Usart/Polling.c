#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : Polling.c
//* Object              : AT91 - USART Controller - Transfert by Polling
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : None
//* Exported resources  : MainApplication
//*
//* 1.0 01/10/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*----------------------------------------------------------------------------
/*
Configure the USART 0 of the AT91 to send and receive bytes on the channel 1
set with local loopback mode.
The channel status is polled to detect the TX and Rx ready.
The byte format is : start + 8 data (without parity) + 1 stop
The baud rate is counter is 53 : 38400 bauds with MCKI = 32.768 MHz
The byte transferred is incremented by one
*/

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#ifndef AT91_DEBUG_NONE
#include <stdio.h>
#endif

/*----- Types and Constants Definition -----*/
#define AT91_REG(x) (*(volatile unsigned int *)(x))

/*----- Imported Resources Definition -----*/
/* None */

/*---- Internal Resources Definition -----*/
/* None */

/*---- External Resources Definition -----*/
#define _REFERENCE(x)   x
#define CORPS
#endif

//*----------------------------------------------------------------------------
//* Function Name       : MainApplication
//* Object              : AT91 - USART Controller - transfert by polling
//* Input Parameters    : None
//* Output Parameters   : None
//* Functions called    : None
//*----------------------------------------------------------------------------
_REFERENCE (int MainApplication( void ))
#ifdef CORPS
//* Begin
{
    unsigned int    loop_count;
    unsigned int    value;

    //* Stop channel
    //* . disable Tx and Rx and clear errors
    AT91_REG(0xFFFCC000) =
        (1 << 7) |          // TXDIS : Transmitter disable
        (1 << 5) |          // RXDIS : Receiver disable
        (1 << 3) |          // RSTTX : Reset Transmitter
        (1 << 2) ;          // RSTRX : Reset Receiver
    for (loop_count = 1000 ; loop_count > 0 ; loop_count--);
    //* . clear PDC counts (Rx and Tx)
    AT91_REG(0xFFFCC034) = AT91_REG(0xFFFCC03C) = 0x00000000;
    //* . Disable ITs
    AT91_REG(0xFFFCC00C) = 0xFFFFFFFF;

    //* Initialize the channel
    //* . Tx and Rx as peripheral
    AT91_REG(0xFFFF0004) =
        (1 << 21) |         // P21 - TXD1
        (1 << 22) ;         // P22 - TRD1
    //* . US_MR - Mode
    AT91_REG(0xFFFCC004) =
        (2 << 14) |         // CHMODE = Local Loopback
        (0 << 12) |         // NBSTOP = 1 stop bit
        (4 <<  9) |         // PAR = No parity
        (0 <<  8) |         // SYNC = asynchronous mode
        (3 <<  6) |         // CHRL = 8 bits
        (0 <<  4) ;         // USCLKS = MCKI
    //* . US_BRGR - Baud Rate Generator
    AT91_REG(0xFFFCC020) = 53;
    //* Start channel
    //* . enable Tx and Rx
    AT91_REG(0xFFFCC000) =
        (1 << 6) |          // TXEN : Transmitter enable
        (1 << 4) ;          // RXEN : Receiver enable
    for (loop_count = 1000 ; loop_count > 0 ; loop_count--);

    for (value = 0 ; ; value++)
    {
        value &= 0x00FF;
#ifndef AT91_DEBUG_NONE
        if (value == 0)
        {
            loop_count ++ ;
            printf ( "Loop %d\n", loop_count ) ;
        }
#endif
        //* Wait Tx ready
        for ( ; (AT91_REG(0xFFFCC014) & (1 << 1)) == 0 ; );
        //* Send byte
        AT91_REG(0xFFFCC01C) = value;
        //* Wait Rx ready
        for ( ; (AT91_REG(0xFFFCC014) & (1 << 0)) == 0 ; );
        //* Receive and check byte
        if (AT91_REG(0xFFFCC018) != value)
        {
#ifndef AT91_DEBUG_NONE
            printf ( "**** 0x'%x' / 0x'%x'\n", AT91_REG(0xFFFCC018), value);
#endif
        }
    }

//* End
    return(0);
}
#endif
