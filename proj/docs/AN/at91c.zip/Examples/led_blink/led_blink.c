#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : led_blink.c
//* Object              : Led Blinking for the AT91DB01.
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : None
//* Exported resources  : main
//*
//* 1.0 26/11/97 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#ifndef AT91_DEBUG_NONE
#include <stdio.h>
#endif

#include    "Include/std_c.h"
#include    "Include/pio.h"
#include    "Include/tc.h"
#include    "Include/eb01.h"

/*----- Types and Constants Definition -----*/
/* None */

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;

#include    "Library/lib_tc.c"
#include    "Library/lib_pio.c"

#undef _REFERENCE

/*---- Internal Resources Definition -----*/
/* None */

/*---- External Resources Definition -----*/
#define _REFERENCE(x)   x
#define CORPS
#endif

volatile u_int      FlagIrq ;


void timer_irq ( StructTC *tc_pt )
{
    read_timer_status ( 2 ) ;
    FlagIrq = TRUE ;
}

void delay ( void )

{
    FlagIrq = FALSE ;

    delay_microsec ( 2, 100000, FALSE, timer_irq ) ;

    while ( FlagIrq != TRUE ) ;

    // u_int    i ;
    // for ( i = 0 ; i < 10000 ; i++ ) ;
}

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : main
//* Object              : Main function of the test "delay"
//* Input Parameters    : none
//* Output Parameters   :
//* Functions called    :
//*-----------------------------------------------------------------------------
_REFERENCE (int MainApplication( void ))
#ifdef CORPS
    //* Begin
{
    u_int   loop_count = 0 ;


    define_as_pio ( 0 , LED1|LED2 );
    define_as_output ( 0, LED1|LED2 );
    set_pio_output ( 0, LED1|LED2  ) ;

    read_timer_status ( 2 ) ;

    init_timer_irq () ;

    for (;;)
    {
        clear_pio_output ( 0, LED1 ) ;

        delay () ;

        clear_pio_output ( 0, LED2 ) ;

        delay () ;

        set_pio_output ( 0, LED1 ) ;

        delay () ;

        set_pio_output ( 0, LED2 ) ;

        delay () ;

#ifndef AT91_DEBUG_NONE
        printf ( "Loop %d\n", loop_count ) ;
#endif
        loop_count ++ ;
    }

//* End
}
#endif
