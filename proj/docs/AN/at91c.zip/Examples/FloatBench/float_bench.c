#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : float_bench.c
//* Object              : Floating point benchmark.
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : float_op_loop_arm
//* Exported resources  : main
//*
//* 1.0 23/09/98 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#include <stdio.h>
#include <float.h>

#include    "Include/std_c.h"     /* Standard C Types */
#include    "Include/aic.h"
#include    "Include/pio.h"
#include    "Include/tc.h"
#include    "Include/eb01.h"

/*----- Types and Constants Definition -----*/
/* None */

//*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;

#include    "Library/lib_pio.c"

#undef _REFERENCE

/*---- Internal Resources Definition -----*/
/* None */

/*---- External Resources Definition -----*/
#define _REFERENCE(x)   x
#define CORPS
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : start_time
//* Object              : Start the Timers to measure time .
//* Input Parameters    : none
//* Output Parameters   : none
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (void start_time ( void ))
#ifdef CORPS
//* Begin
{
    StructTCBlock *tc_ptr = TCB0_BASE ;
    u_int   dummy ;

    //* Clear the timers and TIOA outputs
    tc_ptr->TC[0].TC_CMR = TCMCK2 | WAVE | CPCSTOP |
                           ( ClearOutput << B_ASWTRG ) ;
    tc_ptr->TC[1].TC_CMR = TCMCK2 | WAVE | CPCSTOP |
                           ( ClearOutput << B_ASWTRG ) ;
    tc_ptr->TC[2].TC_CMR = TCMCK2 | WAVE | CPCSTOP |
                           ( ClearOutput << B_ASWTRG ) ;
    tc_ptr->TC[0].TC_RC = 2 ;
    tc_ptr->TC[0].TC_CCR = CLKEN ;
    tc_ptr->TC[1].TC_RC = 2 ;
    tc_ptr->TC[1].TC_CCR = CLKEN ;
    tc_ptr->TC[2].TC_RC = 2 ;
    tc_ptr->TC[2].TC_CCR = CLKEN ;
    tc_ptr->TC_BCR = TCSYNC ;

    //* Define the chain
    tc_ptr->TC_BMR = TIOA0XC1 | TIOA1XC2 ;

    //* Setup Timer 0 as millisecond tick
    tc_ptr->TC[0].TC_CMR = TCMCK2 | WAVE | CPCTRG |
                           ( SetOutput << B_ACPC ) |
                           ( ClearOutput << B_ACPA ) |
                           ( SetOutput << B_ASWTRG ) ;
    tc_ptr->TC[0].TC_RC = ( MCK / 2000 ) - 1 ;
    tc_ptr->TC[0].TC_RA = tc_ptr->TC[0].TC_RC - 1 ;
    tc_ptr->TC[0].TC_CCR = CLKEN ;

    //* Setup Timer 1 as second tick
    tc_ptr->TC[1].TC_CMR = TCXc1 | WAVE | CPCTRG |
                           ( SetOutput << B_ACPC ) |
                           ( ClearOutput << B_ACPA ) |
                           ( SetOutput << B_ASWTRG ) ;
    tc_ptr->TC[1].TC_RC = (1000-1) ;
    tc_ptr->TC[1].TC_RA = (500-1) ;
    tc_ptr->TC[1].TC_CCR = CLKEN ;
    define_as_peripheral ( 0, TIOA1 ) ;
    define_as_output ( 0, TIOA1 ) ;

    //* Setup Timer 2 as second counter
    tc_ptr->TC[2].TC_CMR = TCXc2 | WAVE | CPCTRG |
                           ( SetOutput << B_ACPC ) |
                           ( ClearOutput << B_ACPA ) |
                           ( SetOutput << B_ASWTRG ) ;
    tc_ptr->TC[2].TC_RC = 0xFFFF ;
    tc_ptr->TC[2].TC_CCR = CLKEN ;

    //* Clear the status
    dummy = tc_ptr->TC[0].TC_SR ;
    dummy = tc_ptr->TC[1].TC_SR ;
    dummy = tc_ptr->TC[2].TC_SR ;

    //* Trig Timer2
    tc_ptr->TC[2].TC_CCR = SWTRG ;
    //* Trig Timer1, set TIOA and effective clear timer 2
    tc_ptr->TC[1].TC_CCR = SWTRG ;
    //* Trig Timer0, set TIOA and effective clear timer 1
    tc_ptr->TC[0].TC_CCR = SWTRG ;

//* End
}
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : read_time
//* Object              : Read the Timer and return time .
//* Input Parameters    : none
//* Output Parameters   : Number of microseconds since start.
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (/*float*/ int read_time ( void ))
#ifdef CORPS
//* Begin
{
    StructTCBlock *tc_ptr = TCB0_BASE ;
    int microsec ;

    microsec = (int) ( tc_ptr->TC[0].TC_CV * 1000 / tc_ptr->TC[0].TC_RC ) ;

    microsec += ( tc_ptr->TC[1].TC_CV * 1000 ) ;

    microsec += ( tc_ptr->TC[2].TC_CV * 1000000 ) ;

    //* Return time
    return ( microsec ) ;
//* End
}
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : stop_time
//* Object              : Stop the Timer and return time .
//* Input Parameters    : none
//* Output Parameters   : Number of microseconds since start.
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (/* float */ int stop_time ( void ))
#ifdef CORPS
//* Begin
{
    StructTCBlock *tc_ptr = TCB0_BASE ;

    //* Stop the Timer 0
    tc_ptr->TC[0].TC_CCR = CLKDIS ;

    //* Read counters values
    return ( read_time () ) ;
//* End
}
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : float_op_loop
//* Object              : Float Benchmark Loops.
//* Input Parameters    : none
//* Output Parameters   : none
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (void float_op_loop ( int nb_add,
                                 int nb_sub,
                                 int nb_mul,
                                 int nb_div ))
#ifdef CORPS
//* Begin
{
    u_int   i ;
    volatile float  a, b, c ;

    //* Initialize constant float values
    //b = FLT_MAX /*3.40282347e+38F*/ ;
    //c = FLT_MIN /*1.17549435e-38F*/ ;
    b = 3.40282347e+10F ;
    c = 1.17549435e-15F ;

    //* Perfom the additions
    for ( i = nb_add ; i > 0 ; i --, a=b+c ) ;
    //* Perfom the substractions
    for ( i = nb_sub ; i > 0 ; i --, a=b-c ) ;
    //* Perfom the multiply
    for ( i = nb_mul ; i > 0 ; i --, a=b*c ) ;
    //* Perfom the division
    for ( i = nb_div ; i > 0 ; i --, a=b/c ) ;
//* End
}
#endif


//*P
//*-----------------------------------------------------------------------------
//* Function Name           : main
//* Object                  : Main function of the test "delay"
//* Input Parameters        : none
//* Output Parameters       : none
//* Functions called        :
//*     printf, scanf, start_time, float_op_loop, stop_time
//*-----------------------------------------------------------------------------
_REFERENCE (int MainApplication( void ))
#ifdef CORPS
//* Begin
{
    int     nb_add, nb_sub, nb_mul, nb_div ;
    u_int   time ;

    //* Forever
    for (;;)
    {
        //* Ask for addition number
        printf ( "Addition Number to perform :" ) ;
        scanf ( "%d", &nb_add ) ;
        //* Ask for substraction number
        printf ( "Substract Number to perform :" ) ;
        scanf ( "%d", &nb_sub ) ;
        //* Ask for multiply number
        printf ( "Multiply Number to perform :" ) ;
        scanf ( "%d", &nb_mul ) ;
        //* Ask for division number
        printf ( "Division Number to perform :" ) ;
        scanf ( "%d", &nb_div ) ;

        //* Clear time counter
        start_time () ;
        //* Perform the requested loop
        float_op_loop ( nb_add, nb_sub, nb_mul, nb_div ) ;
        //* Stop the counter and get time
        time = stop_time () ;
        //* Display results
        printf ( "Loop performed in %d microseconds\n", time ) ;
    }

    return ( TRUE ) ;
//* End
}
#endif
