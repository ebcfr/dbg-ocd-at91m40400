#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : lib_pio.c
//* Object              : PIO functions library.
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  :
//*     init_interrupt
//* Exported resources  :
//*     define_as_pio, define_as_peripheral
//*     define_as_output, define_as_input
//*     enable_pio_filter, disable_pio_filter
//*     set_pio_output, clear_pio_output, read_pio_pin
//*     init_pio_interrupt, enable_pio_interrupt, disable_pio_interrupt
//*
//* 1.0 21/10/97 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#ifdef  AT91_TRACE
#include    <stdio.h>
#endif  /* AT91_TRACE */

#include    "Include/std_c.h"
#include    "Include/pio.h"
#include    "Include/aic.h"
#include    "Include/prior_irq.h"

/*----- Types and Constants Definition -----*/
/* None */

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)       extern x;

#include    "Library/lib_aic.c"

#undef _REFERENCE

/* Import the PIO Interrupt Handlers written in assembler */

extern  void pio_interrupt_handler (void) ;

/*---- Internal Resources Definition -----*/

/* PIO Controller's Constant Table Structure */
typedef struct
{
    StructPIO       *PioBase ;
    TypeAICHandler  AsmPioHandler ;
    u_char          PioCtrl ;
    u_char          SourceId ;
    u_char          SourcePrior ;
    u_char          PioNumber ;
} StructConstPio ;

/* PIO Controller's Constant Table Structure */
const StructConstPio ConstPio[NB_PIO_CTRL] =
{
    {
        PIO_BASE,
        pio_interrupt_handler,
        0,
        PIOIRQ,
        PIO_IRQ_PRIORITY,
        NB_PIO
    }
} ;

/* Table of the PIO Handlers for each PIO signal */
TypePIOHandler      PIOHandlerTable[NB_PIO_CTRL][32] ;

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : no_pio_handler
//* Object              : Default pio interrupt handler.
//* Input Parameters    : <pio_pt> = PIO Controller Base Address
//*                     : <mask_pio> = identify the PIO line
//* Output Parameters   : none
//* Functions called    : none
//*-----------------------------------------------------------------------------
/*
This function is the default service routine of an uninitialized
pio interrupt. The user can define the management of this error.
*/
void no_pio_handler ( StructPIO *pio_pt, u_int mask_pio )
{
//* Begin
#ifdef  AT91_TRACE
    printf ( "Unknow PIO Interrupt : 0x%x, 0x%x\n", (u_int) pio_pt, mask_pio ) ;
#endif  /* AT91_TRACE */
//* End
}

/*---- External Resources Definition -----*/

#define _REFERENCE(x)       x
#define CORPS
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : define_as_pio
//* Object              : Define pins as managed by the PIO controller
//* Input Parameters    : <mask> defines the pins to managed by the PIO
//* Output Parameters   : the value of the PIO Status Register
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int define_as_pio ( u_int pio_ctrl_id, u_int mask ))
#ifdef CORPS
//* Begin
{
    //* If PIO Controller index is correct
    if ( pio_ctrl_id > NB_PIO_CTRL ) return ( FALSE ) ;
    //* Write the argument mask in the PIO Enable Register
    ConstPio[pio_ctrl_id].PioBase->PIO_PER = mask ;
    //* Return the value of the PIO Status Register
    return ( ConstPio[pio_ctrl_id].PioBase->PIO_PSR ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : define_as_peripheral
//* Object              : Define pins as managed by a peripheral
//* Input Parameters    : <mask> defines the pins to managed by the peripheral
//* Output Parameters   : the value of the PIO Status Register
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int define_as_peripheral ( u_int pio_ctrl_id, u_int mask ))
#ifdef CORPS
//* Begin
{
    //* If PIO Controller index is correct
    if ( pio_ctrl_id > NB_PIO_CTRL ) return ( FALSE ) ;
    //* Write the argument mask in the PIO Disable Register
    ConstPio[pio_ctrl_id].PioBase->PIO_PDR = mask ;
    //* Return the value of the PIO Status Register
    return ( ConstPio[pio_ctrl_id].PioBase->PIO_PSR ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : define_as_output
//* Object              : Define pins as output if managed by the parallel IO
//* Input Parameters    : <mask> defines the pins to be defined as output
//* Output Parameters   : a mask showing the pins really defined as output
//*                     : bit is set if corresponding pin is an output
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int define_as_output ( u_int pio_ctrl_id, u_int mask ))
#ifdef CORPS
//* Begin
{
    //* If PIO Controller index is correct
    if ( pio_ctrl_id > NB_PIO_CTRL ) return ( FALSE ) ;
    //* Write the argument mask in the Output Enable Register
    ConstPio[pio_ctrl_id].PioBase->PIO_OER = mask ;
    //* Return PIO Status Register AND PIO Direction Status Register
    return ( ConstPio[pio_ctrl_id].PioBase->PIO_PSR &
             ConstPio[pio_ctrl_id].PioBase->PIO_OSR ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : define_as_input
//* Object              : Define pins as input if managed by the parallel IO
//* Input Parameters    : <mask> defines the pins to be defined as input
//* Output Parameters   : a mask showing the pins really defined as input
//*                     : bit is set if corresponding pin is an input
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int define_as_input ( u_int pio_ctrl_id, u_int mask ))
#ifdef CORPS
//* Begin
{
    //* If PIO Controller index is correct
    if ( pio_ctrl_id > NB_PIO_CTRL ) return ( FALSE ) ;
    //* Write the argument mask in the Output Disable Register
    ConstPio[pio_ctrl_id].PioBase->PIO_ODR = mask ;
    //* Return PIO Status Register AND NOT PIO Direction Status Register
    return ( ConstPio[pio_ctrl_id].PioBase->PIO_PSR &
             (~(ConstPio[pio_ctrl_id].PioBase->PIO_OSR)) ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : enable_pio_filter
//* Object              : Enable Glitch filter on pins
//* Input Parameters    : <mask> defines the pins to be filtered
//* Output Parameters   : a mask showing the pins filtered
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int enable_pio_filter ( u_int pio_ctrl_id, u_int mask ))
#ifdef CORPS
//* Begin
{
    //* If PIO Controller index is correct
    if ( pio_ctrl_id > NB_PIO_CTRL ) return ( FALSE ) ;
    //* Write the argument mask in the PIO Output Disable Register
    ConstPio[pio_ctrl_id].PioBase->PIO_IFER = mask ;
    //* Return the Input Filter Status Register
    return ( ConstPio[pio_ctrl_id].PioBase->PIO_IFSR ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : disable_pio_filter
//* Object              : Disable Glitch filter on pins
//* Input Parameters    : <mask> defines the pins to be no more filtered
//* Output Parameters   : a mask showing the pins filtered
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int disable_pio_filter ( u_int pio_ctrl_id, u_int mask ))
#ifdef CORPS
//* Begin
{
    //* If PIO Controller index is correct
    if ( pio_ctrl_id > NB_PIO_CTRL ) return ( FALSE ) ;
    //* Write the argument mask in the PIO Output Disable Register
    ConstPio[pio_ctrl_id].PioBase->PIO_IFDR = mask ;
    //* Return the Filter Status Register
    return ( ConstPio[pio_ctrl_id].PioBase->PIO_IFSR ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : set_pio_output
//* Object              : Set an output if mnaged by the PIO and defined as
//*                     : output
//* Input Parameters    : <mask> defines the pins to be set
//* Output Parameters   : the state of the 32 pins ( on the pads )
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int set_pio_output ( u_int pio_ctrl_id, u_int mask ))
#ifdef CORPS
//* Begin
{
    //* If PIO Controller index is correct
    if ( pio_ctrl_id > NB_PIO_CTRL ) return ( FALSE ) ;
    //* Write the argument mask in the Set Output Data Register
    ConstPio[pio_ctrl_id].PioBase->PIO_SODR = mask ;
    //* Return the Pin Data Status Register
    return ( ConstPio[pio_ctrl_id].PioBase->PIO_PDSR ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : clear_pio_output
//* Object              : Clear an output if managed by the PIO and defined as
//*                     : output
//* Input Parameters    : <mask> defines the pins to be cleared
//* Output Parameters   : the state of the 32 pins ( on the pads )
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int clear_pio_output ( u_int pio_ctrl_id, u_int mask ))
#ifdef CORPS
//* Begin
{
    //* If PIO Controller index is correct
    if ( pio_ctrl_id > NB_PIO_CTRL ) return ( FALSE ) ;
    //* Write the argument mask in the Clear Output Data Register
    ConstPio[pio_ctrl_id].PioBase->PIO_CODR = mask ;
    //* Return the Pin Data Status Register
    return ( ConstPio[pio_ctrl_id].PioBase->PIO_PDSR ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : read_pio_pin
//* Object              : Read the state of the PIO pins
//* Input Parameters    : <mask> defines the pins to be cleared
//* Output Parameters   : the state of the 32 pins ( on the pads )
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int read_pio_pin ( u_int pio_ctrl_id ))
#ifdef CORPS
//* Begin
{
    //* If PIO Controller index is correct
    if ( pio_ctrl_id > NB_PIO_CTRL ) return ( FALSE ) ;
    //* Return the Pin Data Status Register
    return ( ConstPio[pio_ctrl_id].PioBase->PIO_PDSR ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : init_pio_interrupt
//* Object              : Initialize the PIO Interrupt Handler
//* Input Parameters    : none
//* Output Parameters   : Always True
//* Functions called    : init_interrupt
//*-----------------------------------------------------------------------------
_REFERENCE (u_int init_pio_interrupt ( void ))
#ifdef CORPS
//* Begin
{
    u_int       dummy ;
    u_int       pio_ctrl_id ;

    //* For each Pio Controller
    for ( pio_ctrl_id = 0; pio_ctrl_id < NB_PIO_CTRL ; pio_ctrl_id ++ )
    {
        //* Clear all Input Change Interrupts
        dummy = ConstPio[pio_ctrl_id].PioBase->PIO_ISR ;
        //* Initialize the PIO interrupt source in the Interrupt Controller
        init_interrupt ( ConstPio[pio_ctrl_id].SourceId,
                         ConstPio[pio_ctrl_id].SourcePrior,
                         LevelSensitive ,
                         ConstPio[pio_ctrl_id].AsmPioHandler ) ;
    }
    //* Return True
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : enable_pio_interrupt
//* Object              : Enable an input change interrupt on a pin
//* Input Parameters    : <pio_id_ctrl> define the PIO Controller
//*                     : <pio_id> defines the pin on which enable interrupt
//*                     : < service_fct> = the handler to branch on
//* Output Parameters   : The PIO_IMR register value
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int enable_pio_interrupt ( u_int pio_ctrl_id,
                                         u_int pio_id,
                                         TypePIOHandler service_fct ))
#ifdef CORPS
//* Begin
{
    //* If PIO Controller index is correct
    if ( pio_ctrl_id > NB_PIO_CTRL ) return ( FALSE ) ;
    //* Save the Handler Address
    PIOHandlerTable[pio_ctrl_id][pio_id] = service_fct ;
    //* Enable the Interrupt on the Parallel IO Controller
    ConstPio[pio_ctrl_id].PioBase->PIO_IER = 0x01 << pio_id ;
    //* Return Interrupt Mask
    return ( ConstPio[pio_ctrl_id].PioBase->PIO_IMR ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : disable_pio_interrupt
//* Object              : Disable an input change interrupt on a pin
//* Input Parameters    : <pio_id_ctrl> define the PIO Controller
//*                     : <pio_id> defines the pin on which enable interrupt
//* Output Parameters   : The PIO_IMR register value
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int disable_pio_interrupt ( u_int pio_ctrl_id, u_int pio_id ))
#ifdef CORPS
//* Begin
{
    //* If PIO Controller index is correct
    if ( pio_ctrl_id > NB_PIO_CTRL ) return ( FALSE ) ;
    //* Disable the Interrupt on the Parallel IO Controller
    ConstPio[pio_ctrl_id].PioBase->PIO_IDR = 0x01 << pio_id ;
    //* Save the Handler Address
    PIOHandlerTable[pio_ctrl_id][pio_id] = no_pio_handler ;
    //* Return Interrupt Mask
    return ( ConstPio[pio_ctrl_id].PioBase->PIO_IMR ) ;
}
//* End
#endif

