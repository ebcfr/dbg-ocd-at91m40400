#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* File Name           : in_main.c
//* Librarian           : Not applicable
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Treatments          : Get the top of SRAM on the AT91EB01
//*
//* Exported resources  : InitMainSram - Main
//* Imported resources  : InitResetStacks - MainApplication
//*
//* 1.0 04/09/98 JLV    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#include    "Include/std_c.h"
#include    "Include/ebi.h"

/*----- Types and Constants Definition -----*/
/* None */

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;
_REFERENCE (void InitResetStacks( void ))
_REFERENCE (int  MainApplication( void ))
#undef _REFERENCE

/*---- Internal Resources Definition -----*/
/* None */

/*---- External Resources Definition -----*/

#define _REFERENCE(x)   x
#define CORPS
#endif

#ifdef AT91EB01
//*-----------------------------------------------------------------------------
//* Function Name       : InitMainSram
//* Object              : Calculate and return the top of the SRAM
//* Input Parameters    : None
//* Output Parameters   :
//* . size (int) - size of the SRAM
//* Functions called    : None
//*-----------------------------------------------------------------------------
_REFERENCE (int InitMainSram(void))
#ifdef CORPS
//* Begin
{
    int offset;

    //* -- Get SRAM base address and save first short in SRAM
    int sram_base = (EBI_BASE->EBI_CSR[1] & 0xFFFF0000);
    int save_offset0 = *(volatile int *)(sram_base);

    //* -- Fill SRAM (boundaries) until first long overwritten
    *(volatile int *)(sram_base) = -1;
    for (offset = 0x00010000 ;
            *(volatile int *)(sram_base) == -1 ;)
    {
        offset <<= 1;
        *(volatile int *)(sram_base + offset) = offset;
    }

    //* -- restore first short in SRAM
    *(volatile int *)(sram_base) = save_offset0;

    //* Return the size detected
    return (sram_base + offset);

//* End
}/*InitMainSram*/
#endif
#endif /* AT91EB01 */

#ifndef AT91_DEBUG_NONE
//*-----------------------------------------------------------------------------
//* Function Name       : main
//* Object              : Main function of the test "delay"
//* Input Parameters    : none
//* Output Parameters   :
//* Functions called    : InitResetStacks - MainApplication
//*-----------------------------------------------------------------------------
_REFERENCE (int main ( void ))
#ifdef CORPS
//* Begin
{
//* | Stack initialization
      InitResetStacks();
//* | Application activation
      return MainApplication();
//* End
}
#endif
#endif /* AT91_DEBUG_NONE */
