#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : lib_ps.c
//* Object              : Power Saving Library.
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : none
//* Exported resources  : stop_arm_core
//* 1.0 03/12/97 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#include    "Include/std_c.h"
#include    "Include/ps.h"

/*----- Types and Constants Definition -----*/
/* None */

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;
/* None */
#undef _REFERENCE

/*---- Internal Resources Definition -----*/

/* Power Management Controller Base Address */
StructPS    * const PSBase  = PS_BASE ;

/*---- External Resources Definition -----*/

#define _REFERENCE(x)   x
#define CORPS
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : stop_arm_core
//* Object              : Disable the clock on the ARM Core.
//* Input Parameters    : none
//* Output Parameters   : none
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (void stop_arm_core ( void ))
#ifdef CORPS
//* Begin
{
    //* Write the Control Register with bit ARM7DIS set
    PSBase->PS_CR = ARM7DIS ;

/*
The core will exit this function only after an interrupt occurs and is treated.
*/

}
//* End
#endif

