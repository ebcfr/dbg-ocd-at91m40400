#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : lib_ext_irq.c
//* Object              : External Interrupt Library.
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  :
//*     define_as_peripheral
//*     define_as_pio
//*     init_interrupt
//* Exported resources  :
//*     enable_ext_irq
//*     disable_ext_irq
//*
//* 1.0 22/09/98 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#include    "Include/std_c.h"
#include    "Include/aic.h"
#include    "Include/pio.h"
#include    "Include/prior_irq.h"

/*----- Types and Constants Definition -----*/
/* None */

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern  x;

#include    "Library/lib_aic.c"
#include    "Library/lib_pio.c"

#undef _REFERENCE

/* External Interrupt Sources Table Structure */
typedef struct
{
    u_int   PioPin ;
    u_char  SourceId ;
    u_char  SourcePrior ;
    u_char  PioCtrl ;
} StructConstExtIrq ;

/* External Interrupt Sources Table */
const StructConstExtIrq ConstExtIrq[] =
{
    /* FIQ description must be first */
    {
        PIN_FIQ,
        (u_char)FIQ,
        (u_char)0,
        (u_char)PIO_EXT_IRQ
    },
    {
        PIN_IRQ0,
        (u_char)IRQ0,
        (u_char)IRQ0_PRIORITY,
        (u_char)PIO_EXT_IRQ,
    },
    {
        PIN_IRQ1,
        (u_char)IRQ1,
        (u_char)IRQ1_PRIORITY,
        (u_char)PIO_EXT_IRQ,
    },
    {
        PIN_IRQ2,
        (u_char)IRQ2,
        (u_char)IRQ2_PRIORITY,
        (u_char)PIO_EXT_IRQ,
    }
} ;

#define NB_EXT_IRQ  sizeof(ConstExtIrq)/sizeof(StructConstExtIrq)

/*---- Internal Resources Definition -----*/
/* None */

/*---- External Resources Definition -----*/
#define _REFERENCE(x)   x
#define CORPS
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : enable_ext_irq
//* Object              : External Interrupt Set up
//* Input Parameters    : <irq_id>      = interrupt number to initialize
//*                     : <priority>    = priority to give to the interrupt
//*                     : <src_type>    = activation and sense of activation
//*                     : <handler_pt>  = address of the interrupt handler
//* Output Parameters   : False if <irq_id> does not correspond a external
//*                     : interrupt
//* Functions called    :
//*     remove_interrupt, init_interrupt
//*     define_as_peripheral
//*-----------------------------------------------------------------------------
_REFERENCE (u_int enable_ext_irq ( u_int irq_id,
                                   u_int src_type,
                                   TypeAICHandler handler_pt ))
#ifdef CORPS
//* Begin
{
    u_int   src ;

    //* Look for a corresponding source index
    for ( src = 0;
          (( src < NB_EXT_IRQ ) && ( ConstExtIrq[src].SourceId != irq_id )) ;
          src ++ ) ;

    //* If a corresponding external interrupt index is not found, return False
    if ( src >= NB_EXT_IRQ ) return ( FALSE ) ;

    //* Make sure the interrupt source is inactive
    remove_interrupt ( irq_id ) ;
    //* Define the corresponding IRQ line controlled by peripheral
    define_as_peripheral ( ConstExtIrq[src].PioCtrl ,
                           ConstExtIrq[src].PioPin ) ;
    //* Initialize the Interrupt Source on the AIC
    init_interrupt ( irq_id,
                     (u_int) ConstExtIrq[src].SourcePrior,
                     src_type,
                     handler_pt ) ;

    //* Return OK
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : disable_ext_irq
//* Object              : Remove an external interrupt
//* Input Parameters    : <irq_id> = interrupt number to remove
//* Output Parameters   : False if <irq_id> does not correspond a external
//*                     : interrupt
//* Functions called    :
//*     remove_interrupt
//*-----------------------------------------------------------------------------
_REFERENCE (u_int disable_ext_irq ( int irq_id ))
#ifdef CORPS
//* Begin
{
    u_int   src ;

    //* If the interrupt number is not correct, return False
    if ( irq_id > NB_INTERRUPT ) return ( FALSE ) ;

    //* Look for a corresponding source index
    for ( src = 0;
          (( src < NB_EXT_IRQ ) && ( ConstExtIrq[src].SourceId != irq_id )) ;
          src ++ ) ;

    //* If a corresponding external interrupt index is not found, return False
    if ( src >= NB_EXT_IRQ ) return ( FALSE ) ;

    //* Remove the interrupt source from the AIC
    remove_interrupt ( irq_id ) ;
    //* Define the corresponding IRQ line controlled by peripheral
    define_as_pio ( ConstExtIrq[src].PioCtrl ,
                    ConstExtIrq[src].PioPin ) ;

    //* Return True
    return ( TRUE ) ;
}
//* End
#endif

