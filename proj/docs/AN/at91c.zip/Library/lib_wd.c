#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : lib_wd.c
//* Object              : Watch Dog Mamagement Library.
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  :
//*     init_interrupt, remove_interrupt
//* Exported resources  :
//*     init_watch_dog, rearm_watch_dog, disable_watch_dog
//*     read_status_watch_dog, init_test_watch_dog
//*     SaveWDHandler
//*
//* 1.0 10/09/97 JCZ    : Creation
//* 1.1 22/04/98 JLV    : Switch order of WD_CMR and WD_OMR initialization
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/

/* Access Key ( for test purpose only ) */
#define TMRKEY      ((u_int)0xD64A<<16)

/* Test Mode Enable ( for test purpose only )  */
#define TESTEN      (1<<1)

/*----- Files to be included Definition -----*/

#ifdef  AT91_TRACE
#include    <stdio.h>
#endif  /* AT91_TRACE */

#include    "Include/std_c.h"
#include    "Include/wd.h"
#include    "Include/aic.h"
#include    "Include/prior_irq.h"

/*----- Types and Constants Definition -----*/
/* None */

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;

#include    "Library/lib_aic.c"

#undef _REFERENCE

/* Reference the Watch Dog Interrupt Handler written in assembler */
extern void watch_dog_interrupt_handler ( void ) ;

/*---- Internal Resources Definition -----*/

/* Watch Dog Interrupt Handler Address saving */
TypeWDHandler       SaveWDHandler ;

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : no_handler_wd
//* Object              : Default Watch Dog Interrupt Handler
//* Input Parameters    : none
//* Output Parameters   : none
//* Functions called    : none
//*-----------------------------------------------------------------------------
void no_handler_wd ( void )
//* Begin
{
#ifdef  AT91_TRACE
    printf ( "Unknown WatchDog Interrupt \n" ) ;
#endif  /* AT91_TRACE */
}
//* End

/*---- External Resources Definition -----*/

#define _REFERENCE(x)   x
#define CORPS
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : init_watch_dog
//* Object              : Initialize The Watch Dog.
//* Input Parameters    : <mode> = the signals to generate
//*                     : <clock> = the clock selected
//*                     : <count> = the value preloaded in the counter
//*                     : <handler_add> = Handler Address
//* Output Parameters   : TRUE
//* Functions called    : init_interrupt, remove_interrupt
//*-----------------------------------------------------------------------------
_REFERENCE (u_int init_watch_dog ( u_int mode,
                                   u_int clock,
                                   u_int count,
                                   TypeWDHandler handler_add ))
#ifdef CORPS
//* Begin
{
    StructWD    *pt_wd = WD_BASE ;

    //* Disable the Watch Dog
    pt_wd->WD_OMR = OKEY ;

    //* If Watch Dog initialized to generate an interrupt
    if (( mode & IRQEN ) != 0 )
    {
        //* Save the address of the interrupt handler
        SaveWDHandler = handler_add ;
        //* Initialize the Interrupt Controller
        init_interrupt ( WDIRQ ,
                         WD_IRQ_PRIORITY ,
                         EdgeTriggered ,
                         watch_dog_interrupt_handler ) ;
    }
    //* Else
    else
    {
        //* Save the default Watch dog interrupt handler address
        SaveWDHandler = no_handler_wd ;
        //* Disable the Watch Dog Interrupt on the Interrupt Controller
        remove_interrupt ( WDIRQ ) ;
    }
    //* EndIf

    //* Store the Clock Mode Register
    pt_wd->WD_CMR = CKEY | (((count & 0x0000F000) >> 12) << 2) | clock ;
    //* Restart the Watch Dog
    pt_wd->WD_CR = RSTKEY ;
    //* Store the Overflow Mode Register
    pt_wd->WD_OMR = OKEY | mode | WDEN ;
    //* Return True
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : rearm_watch_dog
//* Object              : Restart the Watch Dog counter.
//* Input Parameters    : none
//* Output Parameters   : TRUE
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int rearm_watch_dog ( void ))
#ifdef CORPS
//* Begin
{
    StructWD    *pt_wd = WD_BASE ;

    //* Restart the Watch Dog
    pt_wd->WD_CR = RSTKEY ;

    //* Return True
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : disable_watch_dog
//* Object              : Stop the Watch Dog counter.
//* Input Parameters    : none
//* Output Parameters   : TRUE
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int disable_watch_dog ( void ))
#ifdef CORPS
//* Begin
{
    StructWD    *pt_wd = WD_BASE ;

    //* Restart the Watch Dog
    pt_wd->WD_CR = RSTKEY ;
    //* Disable the Watch Dog
    pt_wd->WD_OMR = OKEY ;
    //* Disable the Watch Dog Interrupt on the Interrupt Controller
    remove_interrupt ( WDIRQ ) ;
    //* Define no Watch dog interrupt handler
    SaveWDHandler = no_handler_wd ;
    //* Return True
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : read_status_watch_dog
//* Object              : Read if Watch Dog counter overflowed.
//* Input Parameters    : none
//* Output Parameters   : the value of the Status Register
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int read_status_watch_dog ( void ))
#ifdef CORPS
//* Begin
{
    //* Return the Status Register of the Watch Dog
    return ( ((StructWD *)WD_BASE)->WD_SR ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : init_test_watch_dog
//* Object              : Initialize The Watch Dog with the test function.
//* Input Parameters    : <mode> = the signals to generate
//*                     : <clock> = the clock selected
//*                     : <count> = the value preloaded in the counter
//*                     : <handler_add> = Handler Address
//* Output Parameters   : TRUE
//* Functions called    : init_interrupt, remove_interrupt
//* Comments            :
//* Warning, this function is not documented in the data sheet and is
//*     only present for test purpose.
//*-----------------------------------------------------------------------------
_REFERENCE (u_int init_test_watch_dog ( u_int mode,
                                        u_int clock,
                                        u_int count,
                                        TypeWDHandler handler_add ))
#ifdef CORPS
//* Begin
{
    StructWD    *pt_wd = WD_BASE ;
    at91_reg    *pt_testreg = (at91_reg *) 0xFFF00014;

    //* Disable the Watch Dog
    pt_wd->WD_OMR = OKEY ;

    //* If Watch Dog initialized to generate an interrupt
    if (( mode & IRQEN ) != 0 )
    {
        //* Save the address of the interrupt handler
        SaveWDHandler = handler_add ;
        //* Initialize the Interrupt Controller
        init_interrupt ( WDIRQ ,
                         WD_IRQ_PRIORITY ,
                         EdgeTriggered ,
                         watch_dog_interrupt_handler ) ;
    }
    //* Else
    else
    {
        //* Save the default Watch dog interrupt handler address
        SaveWDHandler = no_handler_wd ;
        //* Disable the Watch Dog Interrupt on the Interrupt Controller
        remove_interrupt ( WDIRQ ) ;
    }
    //* EndIf

    //* Enable the Test Mode of the Chip
    *pt_testreg = TMRKEY | TESTEN ;
    //* Initialize the preload value of the watch dog counter
    pt_wd->WD_TLR = count ;
    //* Restart the Watch Dog
    pt_wd->WD_CR = RSTKEY ;
    //* Store the Clock Mode Register
    pt_wd->WD_CMR = CKEY | clock ;
    //* Store the Overflow Mode Register
    pt_wd->WD_OMR = OKEY | mode | WDEN ;
    //* Return True
    return ( TRUE ) ;
}
//* End
#endif
