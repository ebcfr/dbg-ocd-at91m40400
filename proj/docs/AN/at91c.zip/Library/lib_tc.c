#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : lib_tc.c
//* Object              : Timer Counter Library.
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  :
//*     tc0_interrupt_handler, tc1_interrupt_handler, tc2_interrupt_handler
//*     define_as_peripheral
//*     init_interrupt
//* Exported resources  :
//*     init_timer_capture
//*     read_timer_status
//*     init_timer_irq, enable_timer_irq, disable_timer_irq
//*     soft_trig_timer
//*     both_pwm_high_first, both_pwm_low_first
//*
//* 1.0 07/08/97 JCZ    : Creation
//* 1.1 21/09/98 JCZ    : delay_microsec : Disable the counter in one shot mode
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/
#ifdef  AT91_TRACE
#include    <stdio.h>
#endif  /* AT91_TRACE */

#include    "Include/std_c.h"
#include    "Include/tc.h"
#include    "Include/aic.h"
#include    "Include/pio.h"
#include    "Include/prior_irq.h"

/*----- Types and Constants Definition -----*/

/* Default the Master clock speed to 32 MHz */
#ifndef MCK
#define MCK     32000000
#define MCKMHz  32
#endif

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;

#include    "Library/lib_aic.c"     /* AIC Library */
#include    "Library/lib_pio.c"     /* PIO Library */

#undef _REFERENCE

/* Reference the TC Interrupt Handlers written in assembler */
extern void tc0_interrupt_handler ( void ) ;
extern void tc1_interrupt_handler ( void ) ;
extern void tc2_interrupt_handler ( void ) ;

/*---- Internal Resources Definition -----*/

typedef struct
{
    StructTCBlock   *TCBBase ;
    u_int           PioPin ;
    TypeAICHandler  TCHandler ;
    u_char          ChannelId ;
    u_char          PioCtrl ;
    u_char          SourceId ;
    u_char          SourcePrior ;
} StructConstTimer ;

const   StructConstTimer    ConstTimer[NB_TIMER] =
{
    /* Timer 0 */
    {
        TCB0_BASE,
        PIN_TC0,
        tc0_interrupt_handler,
        (u_char)0,
        (u_char)PIO_TC0,
        (u_char)TC0IRQ,
        (u_char)TC0_IRQ_PRIORITY
    } ,
    /* Timer 1 */
    {
        TCB0_BASE,
        PIN_TC1,
        tc1_interrupt_handler,
        (u_char)1,
        (u_char)PIO_TC1,
        (u_char)TC1IRQ,
        (u_char)TC1_IRQ_PRIORITY
    } ,
    /* Timer 2 */
    {
        TCB0_BASE,
        PIN_TC2,
        tc2_interrupt_handler,
        (u_char)2,
        (u_char)PIO_TC2,
        (u_char)TC2IRQ,
        (u_char)TC2_IRQ_PRIORITY
    }
} ;

/* Table of the Timer Counter interrupt handler addresses */
TypeTCHandler   TCHandlerTable[NB_TC_BLOCK*NB_TC_CHANNEL] ;

//*P
//*----------------------------------------------------------------------------
//* Function Name       : no_handler_tc
//* Object              : Default TC Handler.
//* Input Parameters    : none
//* Output Parameters   : none
//* Functions called    : none
//*----------------------------------------------------------------------------
void no_handler_tc ( StructTC *tc_pt )
{
//* Begin
#ifdef  AT91_TRACE
    printf ( "Unknown Timer Counter Interrupt : 0x%x\n", (u_int) tc_pt ) ;
#endif  /* AT91_TRACE */
//* End
}

//*P
//*----------------------------------------------------------------------------
//* Function Name       : compute_register
//* Object              : Default TC Handler.
//* Input Parameters    : <mode> : Mode Register image pointer
//*                     : <ra> : RA Register image pointer
//*                     : <rb> : RB Register image pointer
//*                     : <rc> : RC Register image pointer
//* Output Parameters   : True if no error occurs
//* Functions called    : none
//*----------------------------------------------------------------------------
u_int compute_register ( u_int *mode, u_int *ra, u_int *rb, u_int *rc )
{
//* Begin
    u_int   rc_save ;

    //* Check a or b cycle higher than period, return False
    if (( *ra > *rc ) || ( *rb > *rc )) return ( FALSE ) ;

    //* If period(microsec) * MCK(MHz) div 2 < 2, return False
    if (( rc_save = ( *rc * MCKMHz ) >> 1 ) < 2 ) return ( FALSE ) ;

    //* If period(microsec) * MCK(MHz) div 2 < Counter max value
    if ( rc_save < ( 1<<16 ))
    {
        //* Select MCK/2
        *mode = TCMCK2 ;
        //* RA value is a level(microsed)*MCK(MHz) div 2
        *ra = (( *ra * MCKMHz ) >> 1 ) ;
        //* RB value is a level(microsed)*MCK(MHz) div 2
        *rb = (( *rb * MCKMHz ) >> 1 ) ;
    }
    //* Else
    else
    {
        //* If period(microsec) * MCK(MHz) div 8 < Counter max value
        if (( rc_save = ( *rc * MCKMHz ) >> 3 ) < ( 1 << 16 ))
        {
            //* Select MCK/8
            *mode = TCMCK8 ;
            //* RA value is a level(microsed)*MCK(MHz) div 8
            *ra = (( *ra * MCKMHz ) >> 3 ) ;
            //* RB value is a level(microsed)*MCK(MHz) div 8
            *rb = (( *rb * MCKMHz ) >> 3 ) ;
        }
        //* Else
        else
        {
            //* If period(microsec) * MCK(MHz) div 32 < Counter max value
            if (( rc_save = ( *rc * MCKMHz ) >> 5 ) < ( 1 << 16 ))
            {
                //* Select MCK/32
                *mode = TCMCK32 ;
                //* RA value is a level(microsed)*MCK(MHz) div 32
                *ra = (( *ra * MCKMHz ) >> 5 ) ;
                //* RB value is a level(microsed)*MCK(MHz) div 32
                *rb = (( *rb * MCKMHz ) >> 5 ) ;
            }
            //* Else
            else
            {
                //* If period(microsec) * MCK(MHz) div 128 < Counter max value
                if (( rc_save = ( *rc * MCKMHz ) >> 7 ) < ( 1 << 16 ))
                {
                    //* Select MCK/128
                    *mode = TCMCK128 ;
                    //* RA value is a level(microsed)*MCK(MHz) div 128
                    *ra = (( *ra * MCKMHz ) >> 7 ) ;
                    //* RB value is a level(microsed)*MCK(MHz) div 128
                    *rb = (( *rb * MCKMHz ) >> 7 ) ;
                }
                //* Else
                else
                {
                    //* If period(microsec) * MCK(MHz) div 1024 < Counter max value
                    if (( rc_save = ( *rc * MCKMHz ) >> 10 ) < ( 1 << 16 ))
                    {
                        //* Select MCK/1024
                        *mode = TCMCK1024 ;
                        //* RA value is a level(microsed)*MCK(MHz) div 1024
                        *ra = (( *ra * MCKMHz ) >> 10 ) ;
                        //* RB value is a level(microsed)*MCK(MHz) div 1024
                        *rb = (( *rb * MCKMHz ) >> 10 ) ;
                    }
                    //* Else
                    else
                    {
                        //* Return False
                        return ( FALSE ) ;
                    }
                    //* EndIf
                }
                //* EndIf
            }
            //* EndIf
        }
        //* EndIf
    }
    //* EndIf
    *rc = rc_save ;

    //* Return True
    return ( TRUE ) ;
}
//* End


/*---- External Resources Definition -----*/

#define _REFERENCE(x)   x
#define CORPS
#endif

//*P
//*----------------------------------------------------------------------------
//* Function Name       : get_channel_pointer
//* Object              : Get a Timer Counter Channel Base Address
//* Input Parameters    : <timer_id> = the channel number
//* Output Parameters   : The TCC Base Address, or 0 if the timer id is out of
//*                     : range
//* Functions called    : none
//*----------------------------------------------------------------------------
_REFERENCE (StructTC *get_tc_pointer ( u_int timer_id ))
#ifdef CORPS
//* Begin
{
    //* If timer_id is out of range, return False
    if ( timer_id >= NB_TIMER ) return ( (StructTC *) 0 ) ;

    //* Return the value of the Base Address of the channel
    return ( &ConstTimer[timer_id].TCBBase->
                    TC[ConstTimer[timer_id].ChannelId] ) ;
}
//* End
#endif

//*P
//*----------------------------------------------------------------------------
//* Function Name       : read_timer_status
//* Object              : Read the Status of a Timer Counter Channel
//* Input Parameters    : <timer_id> = the channel number
//* Output Parameters   : the status value, or 0 if the timer id is out of range
//* Functions called    : none
//*----------------------------------------------------------------------------
_REFERENCE (u_int read_timer_status ( u_int timer_id ))
#ifdef CORPS
//* Begin
{
    //* If timer_id is out of range, return False
    if ( timer_id >= NB_TIMER ) return ( FALSE ) ;

    //* Return the value of the Status Register
    return ( ConstTimer[timer_id].TCBBase->
                TC[ConstTimer[timer_id].ChannelId].TC_SR ) ;
}
//* End
#endif

//*P
//*----------------------------------------------------------------------------
//* Function Name       : init_timer_irq
//* Object              : Initialize the Timer Counter Handlers
//* Input Parameters    : none
//* Output Parameters   : none
//* Functions called    : none
//*----------------------------------------------------------------------------
_REFERENCE (void init_timer_irq ( void ))
#ifdef CORPS
//* Begin
{
    u_int       tc_id ;

    //* For each timer counter channel
    for ( tc_id = 0 ; tc_id < NB_TIMER ; tc_id ++ )
    {
        //* Initialise the default handler address
        TCHandlerTable[tc_id] = no_handler_tc ;
        //* Enable the interrupt on the Interrupt controller for Timer Counter
        init_interrupt ( ConstTimer[tc_id].SourceId,
                         ConstTimer[tc_id].SourcePrior,
                         EdgeTriggered ,
                         ConstTimer[tc_id].TCHandler ) ;
    }
    //* EndFor
}
//* End
#endif

//*P
//*----------------------------------------------------------------------------
//* Function Name       : enable_timer_irq
//* Object              : Define an Interrupt Handler for a Timer Counter
//* Input Parameters    : <timer_id> = the channel number
//*                     : <mask> = identify the interrupts to enable
//*                     : <handler_pt> = the handler pointer
//* Output Parameters   : False if an error occurs, otherwise True
//* Functions called    : none
//*----------------------------------------------------------------------------
_REFERENCE (u_int enable_timer_irq ( u_int timer_id,
                                     u_int mask,
                                     TypeTCHandler handler_pt ))
#ifdef CORPS
//* Begin
{
    //* If timer index is too high, return False
    if ( timer_id >= NB_TIMER ) return ( FALSE ) ;

    //* Save the address of the interrupt handler in the table
    TCHandlerTable[timer_id] = handler_pt ;
    //* Enable the interrupt
    ConstTimer[timer_id].TCBBase->
            TC[ConstTimer[timer_id].ChannelId].TC_IER = mask ;

    //* Return True
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*----------------------------------------------------------------------------
//* Function Name       : disable_timer_irq
//* Object              : Define pins as managed by the PIO controller
//* Input Parameters    : <mask> defines the pins to managed by the PIO
//* Output Parameters   : the value of the PIO Status Register
//* Functions called    : none
//*----------------------------------------------------------------------------
_REFERENCE (u_int disable_timer_irq ( u_int timer_id ))
#ifdef CORPS
//* Begin
{
    //* If timer index is too high, return False
    if ( timer_id >= NB_TIMER ) return ( FALSE ) ;

    //* Mask all the Timer Counter Channel Interrupt
    ConstTimer[timer_id].TCBBase->
            TC[ConstTimer[timer_id].ChannelId].TC_IDR = 0x1FF ;
    //* Save in the table the default handler address
    TCHandlerTable[timer_id] = no_handler_tc ;

    //* Return True
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*----------------------------------------------------------------------------
//* Function Name       : soft_trig_timer
//* Object              : Generate a software trigger
//* Input Parameters    : <timer_id> = the channel number to trig
//*                     : if timer_id = NB_TIMER, all channels are triggered
//* Output Parameters   : True if the argument is correct, otherwise False
//* Functions called    : none
//*----------------------------------------------------------------------------
_REFERENCE (u_int soft_trig_timer ( u_int timer_id ))
#ifdef CORPS
//* Begin
{
    //* If timer index is too high, return False
    if ( timer_id >= NB_TIMER+NB_TC_BLOCK ) return ( FALSE ) ;

    //* If timer exists
    if ( timer_id < NB_TIMER )
    {
        //* Perform a Software trigger on the corresponding channel
        ConstTimer[timer_id].TCBBase->
                TC[ConstTimer[timer_id].ChannelId].TC_CCR = SWTRG ;
    }
    //* Else
    else
    {
        //* Perform a synchronization trigger
        ConstTimer[(timer_id-NB_TIMER)*NB_TC_CHANNEL].TCBBase->TC_BCR = TCSYNC ;
    }
    //* EndIf

    //* Return True
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*----------------------------------------------------------------------------
//* Function Name       : delay_microsec
//* Object              : Run the specified handler after a defined delay in
//*                     : micro-seconds.
//* Input Parameters    : <timer_id> = the channel number to use
//*                     : <period> = period in micro-seconds
//*                     : <repeat> = if True, handler is run at each period
//*                     : <handler> = the handler to run after the delay
//* Output Parameters   : True if the arguments are correct, otherwise False
//* Functions called    : none
//*----------------------------------------------------------------------------
_REFERENCE (u_int delay_microsec ( u_int timer_id,
                                   u_int period,
                                   u_int repeat,
                                   TypeTCHandler handler ))
#ifdef CORPS
//* Begin
{
    StructTC    *tc_pt ;
    u_int       ra, rb, rc ;
    u_int       mode ;

    //* If timer index is too high, return False
    if ( timer_id >= NB_TIMER ) return ( FALSE ) ;

    //* Define the Timer Counter Channel Pointer
    tc_pt = &(ConstTimer[timer_id].TCBBase->
                    TC[ConstTimer[timer_id].ChannelId]) ;

    //* Compute registers value for maximum precision, if error return False
    //* Define RB as the period to enable stop on Load RB
    ra = 0 ;
    rb = period ;
    rc = period ;
    if ( compute_register ( &mode, &ra, &rb, &rc ) != TRUE ) return ( FALSE ) ;

    //* Define as pio the pins reserved for the Channel
    define_as_pio ( ConstTimer[timer_id].PioCtrl,
                        ConstTimer[timer_id].PioPin ) ;

    //* Save the handler in the table
    TCHandlerTable[timer_id] = handler ;

    //* Initialize the mode of the timer
    tc_pt->TC_CMR = mode | WAVE | (repeat ? CPCTRG : CPCDIS) ;

    //* Initialize the RC Register value
    tc_pt->TC_RC = rc ;

    //* Enable the RC Compare interrupt
    tc_pt->TC_IER = CPCS ;

    //* Enable the clock of the timer
    tc_pt->TC_CCR = CLKEN ;

    //* Trig the timer
    tc_pt->TC_CCR = SWTRG ;

    //* Return True
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*----------------------------------------------------------------------------
//* Function Name       : both_pwm_high_first
//* Object              : Generate 2 PWM waveforms signals defining high level
//*                     : duration
//* Input Parameters    : <timer_id> = the channel number to use
//*                     : <period> = period of both signals in microseconds.
//*                     : <a_cycle> = TIOA high level duration in microseconds
//*                     : <b_cycle> = TIOB high level duration in microseconds
//* Output Parameters   : True if the arguments are correct, otherwise False
//* Functions called    : none
//*----------------------------------------------------------------------------
_REFERENCE (u_int both_pwm_high_first ( u_int timer_id,
                                        u_int period,
                                        u_int a_cycle,
                                        u_int b_cycle ))
#ifdef CORPS
//* Begin
{
    StructTC        *tc_pt ;
    u_int               ra, rb, rc ;
    u_int               mode ;

    //* If timer index is too high, return False
    if ( timer_id >= NB_TIMER ) return ( FALSE ) ;

    //* Define the Timer Counter Channel Pointer
    tc_pt = &(ConstTimer[timer_id].TCBBase->
                    TC[ConstTimer[timer_id].ChannelId]) ;

    //* Compute registers value for maximum precision, if error return False
    ra = a_cycle ;
    rb = b_cycle ;
    rc = period ;
    if ( compute_register ( &mode, &ra, &rb, &rc ) != TRUE ) return ( FALSE ) ;

    //* Define as peripheral the pins reserved for the Channel
    define_as_peripheral ( ConstTimer[timer_id].PioCtrl,
                           ConstTimer[timer_id].PioPin ) ;

    //* Initialize the mode of the timer
    tc_pt->TC_CMR = mode | WAVE | EEVTXc0  | CPCTRG |
                    ( SetOutput << B_BSWTRG ) | ( OutputNone << B_BEEVT ) |
                    ( SetOutput << B_BCPC ) | ( ClearOutput << B_BCPB ) |
                    ( SetOutput << B_ASWTRG ) | ( OutputNone << B_AEEVT ) |
                    ( SetOutput << B_ACPC ) | ( ClearOutput << B_ACPA ) ;

    //* Initialize the RA Register value
    tc_pt->TC_RA = ra ;

    //* Initialize the RB Register value
    tc_pt->TC_RB = rb ;

    //* Initialize the RC Register value
    tc_pt->TC_RC = rc ;

    //* Enable the clock of the timer
    tc_pt->TC_CCR = CLKEN ;

    //* Trig the timer
    tc_pt->TC_CCR = SWTRG ;

    //* Return True
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*----------------------------------------------------------------------------
//* Function Name       : both_pwm_low_first
//* Object              : Generate 2 PWM waveforms signals defining low level
//*                     : duration
//* Input Parameters    : <timer_id> = the channel number to use
//*                     : <period> = period of both signals in microseconds.
//*                     : <a_cycle> = TIOA low level duration in microseconds
//*                     : <b_cycle> = TIOB low level duration in microseconds
//* Output Parameters   : True if the arguments are correct, otherwise False
//* Functions called    : none
//*----------------------------------------------------------------------------
_REFERENCE (u_int both_pwm_low_first ( u_int timer_id,
                                       u_int period,
                                       u_int a_cycle,
                                       u_int b_cycle ))
#ifdef CORPS
//* Begin
{
    StructTC    *tc_pt ;
    u_int       ra, rb, rc ;
    u_int       mode ;

    //* If timer index is too high, return False
    if ( timer_id >= NB_TIMER ) return ( FALSE ) ;

    //* Define the Timer Counter Channel Pointer
    tc_pt = &(ConstTimer[timer_id].TCBBase->
                    TC[ConstTimer[timer_id].ChannelId]) ;

    //* Compute registers value for maximum precision, if error return False
    ra = a_cycle ;
    rb = b_cycle ;
    rc = period ;
    if ( compute_register ( &mode, &ra, &rb, &rc ) != TRUE ) return ( FALSE ) ;

    //* Define as peripheral the pins reserved for the Channel
    define_as_peripheral ( ConstTimer[timer_id].PioCtrl,
                           ConstTimer[timer_id].PioPin ) ;

    //* Initialize the mode of the timer
    tc_pt->TC_CMR = mode | WAVE | EEVTXc0  | CPCTRG |
                    ( ClearOutput << B_BSWTRG ) | ( OutputNone << B_BEEVT ) |
                    ( ClearOutput << B_BCPC ) | ( SetOutput << B_BCPB ) |
                    ( ClearOutput << B_ASWTRG ) | ( OutputNone << B_AEEVT ) |
                    ( ClearOutput << B_ACPC ) | ( SetOutput << B_ACPA ) ;

    //* Initialize the RA Register value
    tc_pt->TC_RA = ra ;

    //* Initialize the RB Register value
    tc_pt->TC_RB = rb ;

    //* Initialize the RC Register value
    tc_pt->TC_RC = rc ;

    //* Enable the clock of the timer
    tc_pt->TC_CCR = CLKEN ;

    //* Trig the timer
    tc_pt->TC_CCR = SWTRG ;

    //* Return True
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*----------------------------------------------------------------------------
//* Function Name       : init_timer_capture
//* Object              : Initialize the TC Channel in Capture Mode
//* Input Parameters    : <timer_id> = channel to initialize
//*                     : <mode> = value of the Mode Register to be programmed
//*                     : <regc> = value of the Register C to be programmed
//* Output Parameters   : False if an error occurs, otherwise True
//* Functions called    : none
//*----------------------------------------------------------------------------
_REFERENCE (u_int init_timer_capture ( u_int timer_id ,
                                       u_int mode ,
                                       u_int regc ))
#ifdef CORPS
//* Begin
{
    StructTC *tc_pt ;

    //* If timer_id is out of range, return False
    if ( timer_id >= NB_TIMER ) return ( FALSE ) ;

    //* Define the Timer Counter Channel Pointer
    tc_pt = &(ConstTimer[timer_id].TCBBase->
                TC[ConstTimer[timer_id].ChannelId]) ;

        //* Define as peripheral the pins reserved for the Channel
    define_as_peripheral ( ConstTimer[timer_id].PioCtrl,
                           ConstTimer[timer_id].PioPin ) ;

    //* Disable the clock on the Timer Counter
    tc_pt->TC_CCR = CLKDIS ;
    //* Initialize the Mode Register of the Channel
    tc_pt->TC_CMR = ( mode & ~WAVE ) ;
    //* Initialize the Register C Value
    tc_pt->TC_RC = regc ;
    //* Enable the Clock
    tc_pt->TC_CCR = CLKEN ;

    //* If no external trigger is enabled
    if (( mode & ETRGEDG ) == 0 )
    {
        //* Send a Software Trigger
        tc_pt->TC_CCR = SWTRG ;
    }
    //* EndIf

    //* Return True
    return ( TRUE ) ;
}
#endif
