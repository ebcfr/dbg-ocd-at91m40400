#ifndef _REFERENCE
//*---------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*---------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : lib_us.c
//* Object              : USART Library.
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  :
//*     init_interrupt
//*     define_as_peripheral, define_as_pio
//*     usart0_interrupt_handler, usart1_interrupt_handler
//* Exported resources  :
//*     init_usart, disable_usart
//*     enable_usart_irq, disable_usart_irq
//*     send_byte, receive_byte
//*     send_frame, receive_frame, get_rx_count
//* 1.0 19/08/97 JCZ    : Creation
//* 1.1 20/04/98 JCZ    : Add function 'get_rx_count'
//*                       Delete 'init_usart_irq'
//* 2.0 21/10/98 JCZ    : Clean up
//*---------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/

/* Number of Loop to detect timeout used by the function <read_byte> */
#define POLLING_READ_TIMEOUT    10000

/*----- Files to be included Definition -----*/

#ifdef  AT91_TRACE
#include    <stdio.h>
#endif  /* AT91_TRACE */

#include    "Include/std_c.h"
#include    "Include/usart.h"
#include    "Include/aic.h"
#include    "Include/pio.h"
#include    "Include/prior_irq.h"

/*----- Types and Constants Definition -----*/
/* None */

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;

#include    "Library/lib_aic.c"
#include    "Library/lib_pio.c"

#undef _REFERENCE

/* Reference the USART Interrupt Handler written in assembler */
extern void usart0_interrupt_handler ( void ) ;
extern void usart1_interrupt_handler ( void ) ;

/*---- Internal Resources Definition -----*/
/* USARTs Constant Table Structure */
typedef struct
{
    StructUSART     *UsartBase ;
    u_int           PioPinRxTx ;
    u_int           PioPinSck ;
    TypeAICHandler  AsmUsartHandler ;
    u_char          PioCtrl ;
    u_char          SourceId ;
    u_char          SourcePrior ;
} StructConstUsart ;

/* USARTs Constant Table Structure */
const StructConstUsart ConstUsart[NB_USART] =
{
    /* Usart 0 */
    {
        USART0_BASE ,
        RXD0|TXD0,
        SCK0,
        usart0_interrupt_handler,
        (u_char)PIO_USART0 ,
        (u_char)US0IRQ ,
        (u_char)USART0_IRQ_PRIORITY ,
    } ,
    /* Usart 1 */
    {
        USART1_BASE ,
        RXD1|TXD1,
        SCK1,
        usart1_interrupt_handler,
        (u_char)PIO_USART1 ,
        (u_char)US1IRQ ,
        (u_char)USART0_IRQ_PRIORITY ,
    }
} ;

/* Table of the interrupt handler addresses */
StructUSARTHandlerTable USARTHandlerTable[NB_USART] ;

//*P
//*---------------------------------------------------------------------------
//* Function Name       : usart_id_handler
//* Object              : Default USART interrupt handler.
//* Input Parameters    : <usart_state> = Status Register of the USART
//* Output Parameters   : none
//* Functions called    : none
//*---------------------------------------------------------------------------
/*
This function is the default service routine of an uninitialized
USART interrupt. The user can define the management of this error.
*/
void no_usart_handler ( StructUSART *usart_pt  )
{
//* Begin
#ifdef  AT91_TRACE
    printf ( "Unknown Usart Interrupt : 0x%x\n", (u_int) usart_pt ) ;
#endif  /* AT91_TRACE */
//* End
}

/*---- External Resources Definition -----*/

#define _REFERENCE(x)   x
#define CORPS
#endif

//*P
//*---------------------------------------------------------------------------
//* Function Name       : init_usart
//* Object              : Initialize an USART.
//* Input Parameters    : <usart_id> = the USART to initialize
//*                     : <mode> = the Mode Register to be programmed
//*                     : <speed> = the BRDR to be programmed
//*                     : <timeguard> = the TTGR to be programmed
//* Output Parameters   : TRUE if USART number is correct, else, FALSE
//* Functions called    : define_as_peripheral
//*---------------------------------------------------------------------------
_REFERENCE (u_int init_usart ( u_int usart_id ,
                               u_int mode ,
                               u_int speed ,
                               u_int timeguard ))
#ifdef CORPS
//* Begin
{
    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* If External clock used
    if (( mode & SCK_USED ) != 0 )
    {
        //* Define RXD, TXD and SCK as peripheral
        define_as_peripheral ( ConstUsart[usart_id].PioCtrl,
                               ConstUsart[usart_id].PioPinRxTx |
                               ConstUsart[usart_id].PioPinSck ) ;
    }
    //* Else
    else
    {
        //* Define RXD and TXD as peripheral
        define_as_peripheral ( ConstUsart[usart_id].PioCtrl,
                               ConstUsart[usart_id].PioPinRxTx ) ;
    }
    //* EndIf

    //* Reset receiver and transmitter
    ConstUsart[usart_id].UsartBase->US_CR = RSTRX | RSTTX | RXDIS | TXDIS ;

    //* Clear the Error Interrupt Mask
    USARTHandlerTable[usart_id].ErrorMask = 0 ;
    //* Default Error Handler on <no_usart_handler>
    USARTHandlerTable[usart_id].ErrorHandler = no_usart_handler ;
    //* Clear the Receive Interrupt Mask
    USARTHandlerTable[usart_id].RxMask = 0 ;
    //* Default Receive Handler on <no_usart_handler>
    USARTHandlerTable[usart_id].RxHandler = no_usart_handler ;
    //* Clear the Transmit Interrupt Mask
    USARTHandlerTable[usart_id].TxMask = 0 ;
    //* Default Transmit Handler on <no_usart_handler>
    USARTHandlerTable[usart_id].TxHandler = no_usart_handler ;

    //* Enable the interrupt on the Interrupt controller for USART
    init_interrupt ( ConstUsart[usart_id].SourceId,
                     ConstUsart[usart_id].SourcePrior,
                     LevelSensitive,
                     ConstUsart[usart_id].AsmUsartHandler ) ;

    //* Clear Transmit and Receive Counters
    ConstUsart[usart_id].UsartBase->US_RCR = 0 ;
    ConstUsart[usart_id].UsartBase->US_TCR = 0 ;

    //* Define the baud rate divisor register
    ConstUsart[usart_id].UsartBase->US_BRGR = speed ;

    //* Define the USART mode
    ConstUsart[usart_id].UsartBase->US_MR = mode  ;

    //* Write the Timeguard Register
    ConstUsart[usart_id].UsartBase->US_TTGR = timeguard ;

    //* Enable receiver and transmitter
    ConstUsart[usart_id].UsartBase->US_CR = RXEN | TXEN ;

    //* Return true
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : disable_usart
//* Object              : Disable an USART.
//* Input Parameters    : <usart_id> = the USART to disable
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : define_as_pio
//*-----------------------------------------------------------------------------
_REFERENCE (u_int disable_usart ( u_int usart_id ))
#ifdef CORPS
//* Begin
{
    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* Define all USARTs pins as pio
    define_as_pio ( ConstUsart[usart_id].PioCtrl,
                    ConstUsart[usart_id].PioPinRxTx |
                    ConstUsart[usart_id].PioPinSck ) ;

    //* Disable all interrupts
    ConstUsart[usart_id].UsartBase->US_IDR = 0xFFFFFFFF ;

    //* Abort the Peripheral Data Transfers
    ConstUsart[usart_id].UsartBase->US_RCR = 0 ;
    ConstUsart[usart_id].UsartBase->US_TCR = 0 ;

    //* Disable receiver and transmitter and stop any activity immediately
    ConstUsart[usart_id].UsartBase->US_CR = TXDIS | RXDIS | RSTTX | RSTRX ;

    //* Return true
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : read_status_usart
//* Object              : Read the Status Register of an USART.
//* Input Parameters    : <usart_id> = the USART to disable
//* Output Parameters   : The status of the USART, 0 if <usart_id> not correct
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int read_status_usart ( u_int usart_id ))
#ifdef CORPS
//* Begin
{
    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* Return Chip Seelct Register Value
    return ( ConstUsart[usart_id].UsartBase->US_CSR ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : reset_status_usart
//* Object              : Reset the Status Bits of an USART.
//* Input Parameters    : <usart_id> = the USART to disable
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int reset_status_usart ( u_int usart_id ))
#ifdef CORPS
//* Begin
{
    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* Send the command to reset the status bits
    ConstUsart[usart_id].UsartBase->US_CR = RSTSTA ;

    //* Return true
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : enable_usart_irq
//* Object              : Enable one or many USART Interrupt.
//* Input Parameters    : <usart_id> = the USART to disable
//*                     : <mask_irq> = the mask of the interrupt to enable
//*                     : <priority> = the USART interrupt source priority
//*                     : <service_irq> = the address of the interrupt handler
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int enable_usart_irq ( u_int usart_id ,
                                     u_int mask_irq ,
                                     TypeUSARTHandler handler_pt ))
#ifdef CORPS
//* Begin
{
    u_int   mask ;

    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* If at least one Receive Bit set in the mask
    if (( mask = ( mask_irq & MASK_IRQ_RX) ) != 0 )
    {
        //* Save the Receive Mask
        USARTHandlerTable[usart_id].RxMask = mask ;
        //* Save the Receive Handler
        USARTHandlerTable[usart_id].RxHandler = handler_pt ;
    }
    //* EndIf

    //* If at least one Transmit Bit set in the mask
    if (( mask = ( mask_irq & MASK_IRQ_TX )) != 0 )
    {
        //* Save the Transmit Mask
        USARTHandlerTable[usart_id].TxMask = mask ;
        //* Save the Transmit Handler
        USARTHandlerTable[usart_id].TxHandler = handler_pt ;
    }
    //* EndIf

    //* If at least one Error Bit set in the mask
    if (( mask = ( mask_irq & MASK_IRQ_ERROR )) != 0 )
    {
        //* Save the Error Mask
        USARTHandlerTable[usart_id].ErrorMask = mask ;
        //* Save the Error Handler
        USARTHandlerTable[usart_id].ErrorHandler = handler_pt ;
    }
    //* EndIf

    //* Enable the interrupt on the USART
    ConstUsart[usart_id].UsartBase->US_IER = mask_irq ;

    //* Return True
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : disable_usart_irq
//* Object              : Disable one or many USART Interrupt.
//* Input Parameters    : <usart_id> = the USART to disable
//*                     : <mask_irq> = the mask of the interrupt to disable
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int disable_usart_irq ( u_int usart_id, u_int mask_irq ))
#ifdef CORPS
//* Begin
{
    u_int mask ;

    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* Disable the interrupt on the USART
    ConstUsart[usart_id].UsartBase->US_IDR = mask_irq ;

    //* If at least one Receive Bit set in the mask
    if (( mask = ( mask_irq & MASK_IRQ_RX )) != 0 )
    {
        //* Clear the Receive Mask
        USARTHandlerTable[usart_id].RxMask &= ~mask ;
        //* Default the Receive Handler to <no_usart_handler>
        USARTHandlerTable[usart_id].RxHandler = no_usart_handler ;
    }
    //* EndIf

    //* If at least one Transmit Bit set in the mask
    if (( mask = ( mask_irq & MASK_IRQ_TX )) != 0 )
    {
        //* Clear the Transmit Mask
        USARTHandlerTable[usart_id].TxMask &= ~mask ;
        //* Default the Transmit Handler to <no_usart_handler>
        USARTHandlerTable[usart_id].TxHandler = no_usart_handler ;
    }
    //* EndIf

    //* If at least one Error Bit set in the mask
    if (( mask = ( mask_irq & MASK_IRQ_ERROR )) != 0 )
    {
        //* Clear the Error Mask
        USARTHandlerTable[usart_id].ErrorMask &= ~mask ;
        //* Default the Error Handler to <no_usart_handler>
        USARTHandlerTable[usart_id].ErrorHandler = no_usart_handler ;
    }
    //* EndIf

    //* Return True
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : usart_command
//* Object              : Send a command to the USART.
//* Input Parameters    : <usart_id> = the USART to disable
//*                     : <mask_command> = the command mask
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int usart_command ( u_int usart_id , u_int mask_command ))
#ifdef CORPS
//* Begin
{
    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* Disable receiver and transmitter and stop any activity immediately
    ConstUsart[usart_id].UsartBase->US_CR = mask_command ;
    //* Return true
    return ( TRUE ) ;
}
//* End
#endif


//*P
//*-----------------------------------------------------------------------------
//* Function Name       : send_byte
//* Object              : Transmit a character.
//* Input Parameters    : <usart_id> = the USART where send the byte
//*                     : <character> = the character to send
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE ( u_int send_byte ( u_int usart_id , u_int character ))
#ifdef CORPS
//* Begin
{
    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* Wait the transmitter Ready signal
    while (( ConstUsart[usart_id].UsartBase->US_CSR & TXRDY) == 0 ) ;

    //* Write the character in the Transmit Holding Register
    ConstUsart[usart_id].UsartBase->US_THR = character ;

    //* Return true
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : receive_byte
//* Object              : Receive a character.
//* Input Parameters    : <usart_id> = the USART where send the byte
//*                     : <pt_char> = pointer where store the character received
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE ( u_int receive_byte ( u_int usart_id , u_int *pt_char ))
#ifdef CORPS
//* Begin
{
    u_int      timeout ;

    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* Initialise the timeout value
    timeout = POLLING_READ_TIMEOUT ;

    //* Wait the transmitter Ready signal
    while ((( ConstUsart[usart_id].UsartBase->US_CSR & RXRDY) == 0 ) &&
           ( timeout-- > 0 )) ;

    //* If no character received
    if (( ConstUsart[usart_id].UsartBase->US_CSR & RXRDY) == 0 )
    {
        //* Return False
        return ( FALSE ) ;
    }

    //* Read the received character and store it
    *pt_char = ConstUsart[usart_id].UsartBase->US_RHR ;
    //* Return True
    return ( TRUE ) ;
}
//* End
#endif


//*P
//*-----------------------------------------------------------------------------
//* Function Name       : send_frame
//* Object              : Transmit a complete.
//* Input Parameters    : <usart_id> = the USART where send the byte
//*                     : <pt_buffer> = the buffer to send
//*                     : <size_buf> = the number of bytes to send
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE ( u_int send_frame ( u_int usart_id ,
                                char *pt_buffer ,
                                u_int size_buf ))
#ifdef CORPS
//* Begin
{
    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* Wait for previous transfer finished
    while (( ConstUsart[usart_id].UsartBase->US_CSR & ENDTX ) == 0 ) ;
    //* Store the address of the buffer
    ConstUsart[usart_id].UsartBase->US_TPR = (u_int) pt_buffer ;
    //* Store the number of bytes to transmit
    ConstUsart[usart_id].UsartBase->US_TCR = size_buf ;
    //* Return true
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : receive_frame
//* Object              : Receive a complete frame.
//* Input Parameters    : <usart_id> = the USART where receive the byte
//*                     : <pt_buffer> = the address of the receive buffer
//*                     : <max_size> = the maximum number of bytes to be
//*                     :              received
//*                     : <timeout> = the inter-character time delay in number
//*                     :             of byte
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE ( u_int receive_frame ( u_int usart_id ,
                                   char *pt_buffer ,
                                   u_int max_size ,
                                   u_int timeout ))
#ifdef CORPS
//* Begin
{
    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* Store the timeout value
    ConstUsart[usart_id].UsartBase->US_RTOR = (timeout * 10 / 4) ;
    //* Restart the timeout logic
    ConstUsart[usart_id].UsartBase->US_CR = STTTO ;
    //* Store the address of the buffer
    ConstUsart[usart_id].UsartBase->US_RPR = (u_int) pt_buffer ;
    //* Store the number of bytes to transmit
    ConstUsart[usart_id].UsartBase->US_RCR = max_size ;
    //* Return true
    return ( TRUE ) ;
}
//* End
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : get_rx_count
//* Object              : Get remaining size of buffer in reception
//* Input Parameters    : <usart_id> = the USART to disable
//*                     : <pt_size> = pointer where store the byte number
//* Output Parameters   : True if <usart_id> is correct
//* Functions called    : None
//*-----------------------------------------------------------------------------
_REFERENCE (u_int get_rx_count ( u_int usart_id , u_int *pt_size ))
#ifdef CORPS
//* Begin
{
    //* If Usart index is too high, return False
    if ( usart_id > NB_USART ) return ( FALSE ) ;

    //* Get the remaining number of bytes
    *pt_size = ConstUsart[usart_id].UsartBase->US_RCR ;

    //* Return true
    return ( TRUE ) ;
}
//* End
#endif
