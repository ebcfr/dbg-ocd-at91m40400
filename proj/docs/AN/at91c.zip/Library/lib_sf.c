#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : lib_sf.c
//* Object              : Special Function Registers Library.
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : None
//* Exported resources  :
//*     read_chip_id
//*
//* 1.0 03/12/97 JCZ    : Creation
//* 2.0 21/10/98 JCZ    : Clean up
//*-----------------------------------------------------------------------------

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/

#include    "Include/std_c.h"
#include    "Include/sf.h"

/*----- Types and Constants Definition -----*/
/* None */

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)   extern x;
/* None */
#undef _REFERENCE

/*---- Internal Resources Definition -----*/

/* Chip Identification Base Address */
StructSF    * const SFBase = SF_BASE ;

/*---- External Resources Definition -----*/

#define _REFERENCE(x)   x
#define CORPS
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : read_chip_id
//* Object              : Read one of the Chip Identification Registers.
//* Input Parameters    : <extension> = if not 0 and valid chip id extension
//*                     : exists, extension chip id is returned
//* Output Parameters   : the chip id register value
//* Functions called    : none
//*-----------------------------------------------------------------------------
_REFERENCE (u_int read_chip_id ( u_int extension ))
#ifdef CORPS
//* Begin
{
    u_int               cid ;

    //* Read the Chip Identification Register
    cid = ( SFBase->SF_CIDR ) ;

    //* If argument <extension> is not zero
    if (( extension != 0 ) && (( cid & EXT ) != 0 ))
    {
        //* Read the value of the extension Chip ID
        cid = SFBase->SF_EXID ;
    }
    //* EndIf

    //* Return the last read register
    return ( cid ) ;
}
//* End
#endif

