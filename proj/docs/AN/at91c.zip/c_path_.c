#ifndef _REFERENCE
//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : c_path.c
//* Object              : AT91 Library Path Definition
//* Translator          : ARM Software Development Toolkit V2.11a
//*
//* Imported resources  : None
//* Exported resources  : c_path
//*
//* 1.0 21/10/98 JCZ    : Creation
//*-----------------------------------------------------------------------------
/*
This file defines the AT91 library path as include path for the compiler.
For this, just add it to the project.
Can be replaced by the defining the option "-I<MyFolderAT91>" to the compiler.
*/

/*----- Called Macro instructions definition -----*/
/* None */

/*----- Files to be included Definition -----*/
/* None */

/*----- Types and Constants Definition -----*/
/* None */

/*----- Imported Resources Definition -----*/

#define _REFERENCE(x)       extern x;

/* None */

#undef _REFERENCE

/*---- Internal Resources Definition -----*/
/* None */

/*---- External Resources Definition -----*/

#define _REFERENCE(x)       x
#define CORPS
#endif

//*P
//*-----------------------------------------------------------------------------
//* Function Name       : c_path
//* Object              : None
//* Input Parameters    : None
//*                     : None
//* Output Parameters   : None
//* Functions called    : None
//*-----------------------------------------------------------------------------
_REFERENCE (void c_path ( void ))
#ifdef CORPS
{
//* Begin
}
//* End
#endif


