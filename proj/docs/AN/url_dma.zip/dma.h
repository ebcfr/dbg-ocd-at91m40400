//*----------------------------------------------------------------------------------
//*		 ATMEL Microcontroller Software Support  -  ROUSSET  -
//*----------------------------------------------------------------------------------
//* File Name			: dma.h
//* Object				: DMA C Prototypes declarations
//* Translator			: ARM Software Development Toolkit V2.11
//*
//* Exported resources	: none
//* Imported resources	: none
//*
//* 1.0 31/07/98 SDC	: Creation
//*----------------------------------------------------------------------------------

#ifndef dma_h
#define dma_h

//* ===== Turbo DMA =====

void DmaTurboSet (int *source, int *destination);
int DmaTurboGet (int *source, int size);
void DmaTurboFiq (void);

//* ===== DMA Channel =====

#define INC_DEST		0x1
#define INC_SRC		0x2

//* DMA Channel descriptor
typedef struct dma_descriptor
{
	u_char	*src;				// Source pointer
	u_char	*dest;				// Destination pointer
	u_int	nb_bytes;			// Total number of bytes to copy
	u_int	nb_packets;			// Maximum number of packets to copy at each FIQ
	u_int	dma_mask;			// DMA channel mask (INC_SRC and/or INC_DEST)
}dma_descriptor;

//* User functions
void DmaChannelFiq (void);
void DmaChannelSet (DMA_DESCRIPTOR *ch, int *tmpBuf);
int DmaChannelGet (void);

#endif


